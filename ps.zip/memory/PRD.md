# Poster Zone — PRD

## Original Problem Statement
> "i want to make a website like the posterized.in where i will send wall posters our company name is poster zone so make a website fully working and ready to publish including frontend backend databases"

User answered "all of these" to the clarification questions, confirming: Stripe payments, both email/password + Google auth, seeded catalog + admin panel, full feature set.

## Architecture
- **Frontend**: React 19 + React Router 7 + Tailwind + Shadcn/UI + Framer Motion + react-fast-marquee. Cormorant Garamond (serif display) + Manrope (body). Editorial gallery aesthetic — monochrome with red accent (#FF3B30).
- **Backend**: FastAPI + Motor (async MongoDB) + emergentintegrations Stripe SDK + JWT/bcrypt + Emergent Google Auth.
- **Database**: MongoDB with collections `posters`, `users`, `user_sessions`, `orders`, `payment_transactions`.
- **Payments**: Stripe Flow B (BYOK) with `sk_test_emergent` — India is not supported for claimable sandboxes.
- **Auth**: Dual — JWT bearer (email/password, stored in localStorage) + session cookie (Google Auth via Emergent).

## User Personas
1. **Shopper** — browses posters, adds to cart, checks out via Stripe, tracks orders.
2. **Admin** — logs in with seeded credentials, adds/edits/deletes posters, manages order statuses.
3. **Guest** — can browse and even check out without an account (guest checkout supported).

## Core Requirements (static)
- Poster catalog with categories, tags, size variants (A4/A3/A2) and frame options.
- Cart with size + frame permutations, localStorage-persisted.
- Stripe checkout for cart-total in INR with success/cancel URLs.
- Order storage + polling-based confirmation on success page.
- Admin CRUD for posters + order status management.

## What's Been Implemented (2026-02-01)
- ✅ Backend API: posters CRUD, categories, auth (JWT + Google), Stripe checkout, orders, admin routes.
- ✅ Seeded catalog: 21 posters × 10 categories.
- ✅ Auto-seeded admin: `admin@posterzone.com / Admin@12345`.
- ✅ Frontend pages: Home, Shop, Product Detail, Cart Drawer, Checkout, Payment Success/Cancel, Login, Signup, Google Auth Callback, Account, Order Detail, Admin, About, Contact.
- ✅ Editorial gallery UI with Cormorant Garamond + Manrope, red accent, marquee, bento grid.
- ✅ End-to-end tested — 19/19 backend tests pass, all frontend flows verified (100/100).

## What's Been Added (2026-02-01 — Iteration 2)
- ✅ **Real image uploads** for admin — Emergent Object Storage backend. `POST /api/admin/upload` accepts multipart, stores in object store, returns public URL. Admin editor modal has an Upload button + live preview.
- ✅ **Wishlist Hearts** — Save-for-later with `POST/GET/DELETE /api/wishlist/{poster_id}`. Guests store in `localStorage` (`pz_wishlist_v1`), which auto-migrates to the server on login. Heart overlay on every poster card, dedicated `/wishlist` page, nav header badge, PDP heart next to Add-to-Cart.
- ✅ **Order emails** via Resend — HTML templates for `order_placed_html` + `order_shipped_html` in `/app/backend/services.py`. Send hooks in Stripe webhook, payment-status poll (order confirmation) and admin status-change to "shipped" (shipped email). **Graceful skip when `RESEND_API_KEY` is empty** — logs `[email skipped — no RESEND_API_KEY]` and never fails order flow. Add key later at `/app/backend/.env` and `sudo supervisorctl restart backend`.
- ✅ Iteration 2 tests: 30/30 backend, 100% frontend.

## Prioritized Backlog (P0/P1/P2)
- **P1**: Wishlist / save-for-later.
- **P1**: Reviews & ratings per poster.
- **P1**: Coupon codes / promo engine.
- **P1**: Related-products upsell on cart page (bundle discount).
- **P1**: Admin poster image upload (currently URL-based); wire to Emergent object storage.
- **P2**: Advanced filters (price range slider, color-picker).
- **P2**: Email notifications on order placement + shipment (Resend/SendGrid).
- **P2**: SEO — dynamic OG images per poster, sitemap.xml.
- **P2**: Multi-currency support.

## Test Credentials
See `/app/memory/test_credentials.md`.
