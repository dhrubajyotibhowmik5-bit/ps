import { useEffect } from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { Toaster } from "sonner";
import { AnimatePresence, motion } from "framer-motion";

import { AuthProvider } from "@/context/AuthContext";
import { CartProvider } from "@/context/CartContext";
import { WishlistProvider } from "@/context/WishlistContext";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";
import CustomCursor from "@/components/CustomCursor";

import Home from "@/pages/Home";
import Shop from "@/pages/Shop";
import ProductDetail from "@/pages/ProductDetail";
import Checkout from "@/pages/Checkout";
import PaymentSuccess from "@/pages/PaymentSuccess";
import PaymentCancel from "@/pages/PaymentCancel";
import PaymentUpi from "@/pages/PaymentUpi";
import Login from "@/pages/Login";
import Signup from "@/pages/Signup";
import AuthCallback from "@/pages/AuthCallback";
import Account from "@/pages/Account";
import Admin from "@/pages/Admin";
import AdminLogin from "@/pages/AdminLogin";
import About from "@/pages/About";
import Contact from "@/pages/Contact";
import OrderDetail from "@/pages/OrderDetail";
import Wishlist from "@/pages/Wishlist";

function ScrollToTop() {
    const { pathname } = useLocation();
    useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
    return null;
}

function AppRouter() {
    const location = useLocation();
    // Synchronous check for session_id in URL hash (from Emergent Google Auth callback)
    if (location.hash?.includes("session_id=")) return <AuthCallback />;

    return (
        <>
            <ScrollToTop />
            <div className="pz-grain" aria-hidden="true" />
            <CustomCursor />
            <Nav />
            <CartDrawer />
            <main>
                <AnimatePresence mode="wait">
                    <motion.div
                        key={location.pathname}
                        initial={{ opacity: 0, y: 12 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -8 }}
                        transition={{ duration: 0.45, ease: [0.2, 0.7, 0.2, 1] }}
                    >
                        <Routes location={location}>
                            <Route path="/" element={<Home />} />
                            <Route path="/shop" element={<Shop />} />
                            <Route path="/product/:slug" element={<ProductDetail />} />
                            <Route path="/checkout" element={<Checkout />} />
                            <Route path="/payment/success" element={<PaymentSuccess />} />
                            <Route path="/payment/cancel" element={<PaymentCancel />} />
                            <Route path="/payment/upi" element={<PaymentUpi />} />
                            <Route path="/login" element={<Login />} />
                            <Route path="/signup" element={<Signup />} />
                            <Route path="/auth/callback" element={<AuthCallback />} />
                            <Route path="/account" element={<Account />} />
                            <Route path="/admin" element={<Admin />} />
                            <Route path="/admin/login" element={<AdminLogin />} />
                            <Route path="/order/:orderId" element={<OrderDetail />} />
                            <Route path="/wishlist" element={<Wishlist />} />
                            <Route path="/about" element={<About />} />
                            <Route path="/contact" element={<Contact />} />
                        </Routes>
                    </motion.div>
                </AnimatePresence>
            </main>
            <Footer />
        </>
    );
}

function App() {
    return (
        <div className="App">
            <BrowserRouter>
                <AuthProvider>
                    <WishlistProvider>
                        <CartProvider>
                            <AppRouter />
                            <Toaster position="bottom-right" richColors />
                        </CartProvider>
                    </WishlistProvider>
                </AuthProvider>
            </BrowserRouter>
        </div>
    );
}

export default App;
