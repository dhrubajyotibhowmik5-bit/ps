import React, { useEffect, useState, useRef } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { api } from "@/lib/api";
import { useCart } from "@/context/CartContext";
import { CheckCircle2, XCircle, Loader2 } from "lucide-react";

const MAX_POLLS = 8;

export default function PaymentSuccess() {
    const [params] = useSearchParams();
    const sessionId = params.get("session_id");
    const [status, setStatus] = useState("checking");
    const [orderId, setOrderId] = useState(sessionStorage.getItem("pz_last_order"));
    const pollCount = useRef(0);
    const timer = useRef(null);
    const { clear } = useCart();

    useEffect(() => {
        if (!sessionId) {
            setStatus("error");
            return;
        }
        const poll = async () => {
            try {
                const { data } = await api.get(`/payments/status/${sessionId}`);
                if (data.order_id) setOrderId(data.order_id);
                if (data.payment_status === "paid") {
                    setStatus("paid");
                    clear();
                    sessionStorage.removeItem("pz_last_order");
                    return;
                }
                if (["expired", "failed"].includes(data.payment_status)) {
                    setStatus("failed");
                    return;
                }
                pollCount.current += 1;
                if (pollCount.current >= MAX_POLLS) {
                    setStatus("timeout");
                    return;
                }
                timer.current = setTimeout(poll, 2000);
            } catch (e) {
                setStatus("error");
            }
        };
        poll();
        return () => timer.current && clearTimeout(timer.current);
        // eslint-disable-next-line
    }, [sessionId]);

    return (
        <div className="max-w-[800px] mx-auto px-6 py-24 text-center" data-testid="payment-success-page">
            {status === "checking" && (
                <>
                    <Loader2 className="w-10 h-10 mx-auto animate-spin text-pz-muted" />
                    <h1 className="mt-6 font-serif-display text-4xl">Confirming your order…</h1>
                    <p className="mt-2 text-pz-muted">Please don’t close this tab.</p>
                </>
            )}
            {status === "paid" && (
                <>
                    <CheckCircle2 className="w-14 h-14 mx-auto text-[#FF3B30]" />
                    <h1 data-testid="payment-success-title" className="mt-6 font-serif-display text-5xl italic">On the way.</h1>
                    <p className="mt-4 text-pz-muted">Thanks for shopping with Poster Zone. Your order has been confirmed and will be dispatched within 2 business days.</p>
                    {orderId && <div className="mt-4 text-sm">Order ID: <span data-testid="payment-success-order-id" className="font-medium">{orderId}</span></div>}
                    <div className="mt-8 flex gap-3 justify-center">
                        {orderId && <Link data-testid="payment-success-view-order" to={`/order/${orderId}`} className="pz-btn">Track order</Link>}
                        <Link data-testid="payment-success-continue" to="/shop" className="pz-btn pz-btn-outline">Continue shopping</Link>
                    </div>
                </>
            )}
            {["failed", "timeout", "error"].includes(status) && (
                <>
                    <XCircle className="w-14 h-14 mx-auto text-pz-muted" />
                    <h1 className="mt-6 font-serif-display text-4xl">Payment not confirmed.</h1>
                    <p className="mt-2 text-pz-muted">If you were charged, contact us at hello@posterzone.in with your session id.</p>
                    <div className="mt-8 flex gap-3 justify-center">
                        <Link to="/checkout" className="pz-btn">Try again</Link>
                        <Link to="/shop" className="pz-btn pz-btn-outline">Back to shop</Link>
                    </div>
                </>
            )}
        </div>
    );
}
