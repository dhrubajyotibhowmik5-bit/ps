import React, { useEffect, useRef, useState } from "react";
import { Navigate } from "react-router-dom";
import { api, formatPrice, API } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Trash2, Plus, Edit2, Upload, Loader2, UploadCloud, FileText } from "lucide-react";
import BulkUploadModal from "@/components/BulkUploadModal";
import CsvImportModal from "@/components/CsvImportModal";

const EMPTY = {
    slug: "",
    title: "",
    description: "",
    price: 199,
    category: "Movies",
    tags: [],
    image_url: "",
    sizes: [
        { label: "A4 (8x11 in)", price_delta: 0 },
        { label: "A3 (12x17 in)", price_delta: 200 },
        { label: "A2 (17x23 in)", price_delta: 500 },
    ],
    frame_options: [
        { label: "No Frame", price_delta: 0 },
        { label: "Black Frame", price_delta: 300 },
        { label: "White Frame", price_delta: 300 },
        { label: "Natural Wood", price_delta: 400 },
    ],
    stock: 100,
    featured: false,
};

export default function Admin() {
    const { user, loading } = useAuth();
    const [posters, setPosters] = useState([]);
    const [orders, setOrders] = useState([]);
    const [editing, setEditing] = useState(null); // null = closed, {} = new
    const [form, setForm] = useState(EMPTY);
    const [uploading, setUploading] = useState(false);
    const [bulkOpen, setBulkOpen] = useState(false);
    const [csvOpen, setCsvOpen] = useState(false);
    const fileInputRef = useRef(null);

    const uploadImage = async (file) => {
        if (!file) return;
        if (file.size > 8 * 1024 * 1024) {
            toast.error("File too large (max 8MB)");
            return;
        }
        setUploading(true);
        try {
            const fd = new FormData();
            fd.append("file", file);
            const { data } = await api.post("/admin/upload", fd, {
                headers: { "Content-Type": "multipart/form-data" },
            });
            // Build full URL to store in poster's image_url
            const fullUrl = data.url.startsWith("http") ? data.url : `${API.replace(/\/api$/, "")}${data.url}`;
            setForm((f) => ({ ...f, image_url: fullUrl }));
            toast.success("Image uploaded");
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Upload failed");
        } finally {
            setUploading(false);
        }
    };

    const loadAll = async () => {
        const [p, o] = await Promise.all([
            api.get("/posters", { params: { limit: 500 } }),
            api.get("/admin/orders"),
        ]);
        setPosters(p.data);
        setOrders(o.data);
    };

    useEffect(() => {
        if (user?.role === "admin") loadAll();
    }, [user]);

    if (loading) return <div className="p-16 text-pz-muted">Loading…</div>;
    if (!user) return <Navigate to="/admin/login" replace />;
    if (user.role !== "admin") return <Navigate to="/account" replace />;

    const openNew = () => { setForm(EMPTY); setEditing({}); };
    const openEdit = (p) => { setForm({ ...p, tags: p.tags || [] }); setEditing(p); };
    const close = () => { setEditing(null); setForm(EMPTY); };

    const savePoster = async (e) => {
        e.preventDefault();
        try {
            const payload = { ...form, price: Number(form.price), stock: Number(form.stock) };
            if (editing?.id) {
                await api.put(`/admin/posters/${editing.id}`, payload);
                toast.success("Poster updated");
            } else {
                await api.post("/admin/posters", payload);
                toast.success("Poster created");
            }
            close();
            loadAll();
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Save failed");
        }
    };

    const deletePoster = async (p) => {
        if (!confirm(`Delete "${p.title}"?`)) return;
        await api.delete(`/admin/posters/${p.id}`);
        toast.success("Deleted");
        loadAll();
    };

    const updateOrderStatus = async (id, status) => {
        await api.put(`/admin/orders/${id}/status`, { status });
        toast.success(`Order → ${status}`);
        loadAll();
    };

    const markUpiPaid = async (id) => {
        if (!confirm(`Confirm you have received UPI payment for ${id}?`)) return;
        try {
            await api.post(`/admin/orders/${id}/mark-upi-paid`);
            toast.success("Marked as paid");
            loadAll();
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Failed");
        }
    };

    const stats = {
        posters: posters.length,
        orders: orders.length,
        revenue: orders.filter((o) => o.payment_status === "paid").reduce((s, o) => s + o.total, 0),
        pending: orders.filter((o) => o.status === "placed").length,
    };

    return (
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-16" data-testid="admin-page">
            <div className="eyebrow mb-3">Admin</div>
            <h1 className="font-serif-display text-5xl lg:text-6xl tracking-tighter">Dashboard<span className="text-[#FF3B30]">.</span></h1>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-10">
                <Stat label="Total Posters" value={stats.posters} />
                <Stat label="Total Orders" value={stats.orders} />
                <Stat label="Revenue" value={formatPrice(stats.revenue)} />
                <Stat label="Awaiting Ship" value={stats.pending} />
            </div>

            <Tabs defaultValue="posters" className="mt-12">
                <TabsList>
                    <TabsTrigger data-testid="admin-tab-posters" value="posters">Posters</TabsTrigger>
                    <TabsTrigger data-testid="admin-tab-orders" value="orders">Orders</TabsTrigger>
                </TabsList>

                <TabsContent value="posters" className="mt-8">
                    <div className="flex justify-between items-center mb-6 flex-wrap gap-3">
                        <div className="text-sm text-pz-muted">{posters.length} prints in catalog</div>
                        <div className="flex gap-2">
                            <button data-testid="admin-csv-import-btn" onClick={() => setCsvOpen(true)} className="pz-btn pz-btn-outline">
                                <FileText className="w-4 h-4" /> CSV Import
                            </button>
                            <button data-testid="admin-bulk-upload-btn" onClick={() => setBulkOpen(true)} className="pz-btn pz-btn-outline">
                                <UploadCloud className="w-4 h-4" /> Bulk Upload
                            </button>
                            <button data-testid="admin-new-poster" onClick={openNew} className="pz-btn pz-btn-accent">
                                <Plus className="w-4 h-4" /> New Poster
                            </button>
                        </div>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4" data-testid="admin-posters-grid">
                        {posters.map((p) => (
                            <div key={p.id} className="border border-pz-border" data-testid={`admin-poster-${p.slug}`}>
                                <div className="aspect-[4/5] bg-pz-surface overflow-hidden">
                                    <img src={p.image_url} alt="" className="w-full h-full object-cover" />
                                </div>
                                <div className="p-3">
                                    <div className="text-xs text-pz-muted">{p.category}</div>
                                    <div className="font-medium truncate">{p.title}</div>
                                    <div className="text-sm mt-1">{formatPrice(p.price)}</div>
                                    <div className="flex gap-2 mt-3">
                                        <button data-testid={`admin-edit-${p.slug}`} onClick={() => openEdit(p)} className="text-xs flex items-center gap-1 hover:text-[#FF3B30]"><Edit2 className="w-3 h-3" /> Edit</button>
                                        <button data-testid={`admin-delete-${p.slug}`} onClick={() => deletePoster(p)} className="text-xs flex items-center gap-1 hover:text-[#FF3B30]"><Trash2 className="w-3 h-3" /> Delete</button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </TabsContent>

                <TabsContent value="orders" className="mt-8">
                    {orders.length === 0 ? (
                        <div className="text-pz-muted">No orders yet.</div>
                    ) : (
                        <div className="overflow-x-auto" data-testid="admin-orders-table">
                            <table className="w-full text-sm">
                                <thead className="text-left border-b border-pz-border">
                                    <tr>
                                        <th className="py-3 eyebrow">Order</th>
                                        <th className="py-3 eyebrow">Customer</th>
                                        <th className="py-3 eyebrow">Total</th>
                                        <th className="py-3 eyebrow">Method</th>
                                        <th className="py-3 eyebrow">Payment</th>
                                        <th className="py-3 eyebrow">Status</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {orders.map((o) => (
                                        <tr key={o.order_id} className="border-b border-pz-border" data-testid={`admin-order-row-${o.order_id}`}>
                                            <td className="py-3">{o.order_id}</td>
                                            <td className="py-3">{o.shipping_address?.name}<br /><span className="text-xs text-pz-muted">{o.shipping_address?.email}</span></td>
                                            <td className="py-3">{formatPrice(o.total)}</td>
                                            <td className="py-3 text-xs uppercase tracking-wider">{o.payment_method || "upi"}</td>
                                            <td className="py-3">
                                                <span className={`capitalize text-xs ${o.payment_status === "paid" ? "text-emerald-700" : o.payment_status === "awaiting_verification" ? "text-amber-700" : "text-pz-muted"}`}>
                                                    {(o.payment_status || "pending").replace(/_/g, " ")}
                                                </span>
                                                {o.payment_method === "upi" && o.payment_status !== "paid" && (
                                                    <button
                                                        data-testid={`admin-mark-upi-paid-${o.order_id}`}
                                                        onClick={() => markUpiPaid(o.order_id)}
                                                        className="block mt-1 text-[10px] tracking-widest uppercase text-[#FF3B30] hover:underline"
                                                    >
                                                        Mark paid →
                                                    </button>
                                                )}
                                            </td>
                                            <td className="py-3">
                                                <select
                                                    data-testid={`admin-order-status-${o.order_id}`}
                                                    value={o.status}
                                                    onChange={(e) => updateOrderStatus(o.order_id, e.target.value)}
                                                    className="border border-pz-border p-1 bg-transparent text-xs"
                                                >
                                                    {["pending_payment", "awaiting_upi_verification", "placed", "processing", "shipped", "delivered", "cancelled"].map((s) =>
                                                        <option key={s} value={s}>{s.replace(/_/g, " ")}</option>
                                                    )}
                                                </select>
                                            </td>
                                            <td className="py-3 text-xs text-pz-muted">{new Date(o.created_at).toLocaleDateString()}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </TabsContent>
            </Tabs>

            {/* Editor modal */}
            {editing !== null && (
                <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" data-testid="admin-editor-modal">
                    <div className="bg-white w-full max-w-2xl max-h-[90vh] overflow-y-auto">
                        <div className="p-6 border-b border-pz-border flex justify-between items-center">
                            <h3 className="font-serif-display text-3xl">{editing?.id ? "Edit Poster" : "New Poster"}</h3>
                            <button onClick={close} className="text-pz-muted hover:text-pz-ink">✕</button>
                        </div>
                        <form onSubmit={savePoster} className="p-6 space-y-4">
                            <Field label="Title" testId="admin-form-title" value={form.title} onChange={(v) => setForm({ ...form, title: v })} required />
                            <Field label="Slug (url-safe)" testId="admin-form-slug" value={form.slug} onChange={(v) => setForm({ ...form, slug: v })} required />
                            <Field label="Description" testId="admin-form-description" value={form.description} onChange={(v) => setForm({ ...form, description: v })} textarea required />
                            <div className="grid grid-cols-2 gap-4">
                                <Field label="Category" testId="admin-form-category" value={form.category} onChange={(v) => setForm({ ...form, category: v })} required />
                                <Field label="Price (₹)" testId="admin-form-price" type="number" value={form.price} onChange={(v) => setForm({ ...form, price: v })} required />
                            </div>
                            <Field label="Image URL" testId="admin-form-image" value={form.image_url} onChange={(v) => setForm({ ...form, image_url: v })} required />
                            <div className="flex items-center gap-3">
                                <input
                                    ref={fileInputRef}
                                    data-testid="admin-form-image-file"
                                    type="file"
                                    accept="image/png,image/jpeg,image/webp,image/gif"
                                    className="hidden"
                                    onChange={(e) => uploadImage(e.target.files?.[0])}
                                />
                                <button
                                    data-testid="admin-form-upload-btn"
                                    type="button"
                                    onClick={() => fileInputRef.current?.click()}
                                    disabled={uploading}
                                    className="pz-btn pz-btn-outline gap-2 text-xs"
                                >
                                    {uploading ? <><Loader2 className="w-4 h-4 animate-spin" /> Uploading…</> : <><Upload className="w-4 h-4" /> Upload image</>}
                                </button>
                                {form.image_url && (
                                    <img data-testid="admin-form-image-preview" src={form.image_url} alt="preview" className="w-16 h-20 object-cover border border-pz-border" />
                                )}
                                <span className="text-xs text-pz-muted">Upload or paste a URL above · Max 8MB</span>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <Field label="Stock" testId="admin-form-stock" type="number" value={form.stock} onChange={(v) => setForm({ ...form, stock: v })} />
                                <label className="flex items-center gap-3 mt-6">
                                    <input data-testid="admin-form-featured" type="checkbox" checked={form.featured} onChange={(e) => setForm({ ...form, featured: e.target.checked })} />
                                    <span className="text-sm">Featured on home</span>
                                </label>
                            </div>
                            <div className="flex gap-3 pt-4">
                                <button data-testid="admin-form-save" type="submit" className="pz-btn">Save</button>
                                <button type="button" onClick={close} className="pz-btn pz-btn-outline">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
            {/* Bulk upload modal */}
            <BulkUploadModal open={bulkOpen} onClose={() => setBulkOpen(false)} onDone={loadAll} />
            {/* CSV import modal */}
            <CsvImportModal open={csvOpen} onClose={() => setCsvOpen(false)} onDone={loadAll} />
        </div>
    );
}

function Stat({ label, value }) {
    return (
        <div className="border border-pz-border p-6">
            <div className="eyebrow mb-2">{label}</div>
            <div className="font-serif-display text-4xl tracking-tighter">{value}</div>
        </div>
    );
}

function Field({ label, testId, value, onChange, type = "text", textarea = false, required = false }) {
    return (
        <label className="block">
            <div className="eyebrow mb-1">{label}</div>
            {textarea ? (
                <textarea data-testid={testId} value={value} required={required} onChange={(e) => onChange(e.target.value)} rows={3}
                    className="w-full border border-pz-border p-2 outline-none focus:border-pz-ink text-sm" />
            ) : (
                <input data-testid={testId} type={type} value={value} required={required} onChange={(e) => onChange(e.target.value)}
                    className="w-full border border-pz-border p-2 outline-none focus:border-pz-ink text-sm" />
            )}
        </label>
    );
}
