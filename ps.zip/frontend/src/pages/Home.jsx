import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import Marquee from "react-fast-marquee";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { api } from "@/lib/api";
import PosterCard from "@/components/PosterCard";
import { AnimatedHeading, Reveal, StaggerContainer, StaggerChild } from "@/components/motion";

export default function Home() {
    const [posters, setPosters] = useState([]);
    const [categories, setCategories] = useState([]);
    const heroImgRef = useRef(null);
    const { scrollY } = useScroll();
    const heroY = useTransform(scrollY, [0, 800], [0, -120]);
    const heroScale = useTransform(scrollY, [0, 800], [1, 1.06]);
    const badgeRotate = useTransform(scrollY, [0, 1000], [0, 360]);

    useEffect(() => {
        api.get("/posters", { params: { featured: true, limit: 8 } }).then((r) => setPosters(r.data));
        api.get("/posters/categories").then((r) => setCategories(r.data));
    }, []);

    const heroPoster = posters[0];
    const grid = posters.slice(1, 7);

    return (
        <div data-testid="home-page">
            {/* HERO */}
            <section className="relative border-b border-pz-border overflow-hidden">
                <div className="max-w-[1400px] mx-auto px-6 lg:px-10 pt-14 lg:pt-20 pb-20 lg:pb-28 grid lg:grid-cols-12 gap-10 items-end">
                    <div className="lg:col-span-5">
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.7, delay: 0.1 }}
                            className="eyebrow mb-6"
                        >
                            Est. 2026 · Curated Wall Art
                        </motion.div>
                        <h1 className="font-serif-display text-6xl md:text-7xl lg:text-[104px] leading-[0.88] tracking-tighter overflow-hidden">
                            <div className="overflow-hidden">
                                <AnimatedHeading delay={0.15} stagger={0.06}>Walls with</AnimatedHeading>
                            </div>
                            <div className="overflow-hidden italic font-light">
                                <AnimatedHeading delay={0.35} stagger={0.06}>a story</AnimatedHeading>
                            </div>
                            <div className="overflow-hidden text-[#FF3B30]">
                                <AnimatedHeading delay={0.55} stagger={0.06}>to tell.</AnimatedHeading>
                            </div>
                        </h1>
                        <motion.p
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.7, delay: 0.9 }}
                            className="mt-8 text-pz-muted max-w-md leading-relaxed"
                        >
                            Museum-grade poster prints, obsessively curated across cinema, anime, minimal art & more. Print it, ship it, live with it.
                        </motion.p>
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.7, delay: 1.05 }}
                            className="mt-10 flex flex-wrap gap-3"
                        >
                            <Link data-testid="hero-shop-cta" to="/shop" className="pz-btn">
                                Shop the collection <ArrowRight className="w-4 h-4 hover-arrow" />
                            </Link>
                            <Link data-testid="hero-about-cta" to="/about" className="pz-btn pz-btn-outline">
                                Our story
                            </Link>
                        </motion.div>
                    </div>

                    <div className="lg:col-span-7 relative" ref={heroImgRef}>
                        <motion.div
                            style={{ y: heroY, scale: heroScale }}
                            className="grid grid-cols-3 gap-3 lg:gap-5"
                        >
                            <motion.div
                                initial={{ opacity: 0, scale: 0.94 }}
                                animate={{ opacity: 1, scale: 1 }}
                                transition={{ duration: 0.9, delay: 0.3, ease: [0.2, 0.7, 0.2, 1] }}
                                className="col-span-2 row-span-2 aspect-[3/4] overflow-hidden bg-pz-surface"
                            >
                                <img
                                    src="https://images.pexels.com/photos/4067759/pexels-photo-4067759.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
                                    alt="Featured wall gallery"
                                    className="w-full h-full object-cover"
                                />
                            </motion.div>
                            <motion.div
                                initial={{ opacity: 0, y: 30 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ duration: 0.8, delay: 0.55 }}
                                className="aspect-[3/4] overflow-hidden bg-pz-surface"
                            >
                                <img src="https://images.unsplash.com/photo-1706630909453-c1058a447373?auto=format&fit=crop&w=800&q=80" alt="" className="w-full h-full object-cover" />
                            </motion.div>
                            <motion.div
                                initial={{ opacity: 0, y: 30 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ duration: 0.8, delay: 0.75 }}
                                className="aspect-[3/4] overflow-hidden bg-pz-surface"
                            >
                                <img src="https://images.unsplash.com/photo-1705420292539-ac64810ef8a1?auto=format&fit=crop&w=800&q=80" alt="" className="w-full h-full object-cover" />
                            </motion.div>
                        </motion.div>

                        {/* Rotating badge */}
                        <motion.div
                            style={{ rotate: badgeRotate }}
                            className="absolute -bottom-6 -right-6 md:-bottom-10 md:-right-10 w-32 h-32 md:w-40 md:h-40 rounded-full bg-[#FF3B30] text-white flex items-center justify-center hidden md:flex"
                        >
                            <svg viewBox="0 0 200 200" className="w-full h-full absolute inset-0" aria-hidden="true">
                                <defs>
                                    <path id="circle-text" d="M 100,100 m -74,0 a 74,74 0 1,1 148,0 a 74,74 0 1,1 -148,0" />
                                </defs>
                                <text fontSize="14" fontFamily="Manrope, sans-serif" fill="#fff" letterSpacing="4">
                                    <textPath href="#circle-text">SHOP · NEW ARRIVALS · SHOP · NEW ARRIVALS · </textPath>
                                </text>
                            </svg>
                            <ArrowUpRight className="w-8 h-8" />
                        </motion.div>

                        <motion.div
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ duration: 0.7, delay: 1.0 }}
                            className="absolute -bottom-4 lg:-bottom-8 left-4 lg:left-6 bg-pz-ink text-white px-6 py-4 max-w-xs hidden md:block"
                        >
                            <div className="eyebrow text-white/60 mb-1">This month</div>
                            <div className="font-serif-display text-2xl leading-tight italic">Cinema, framed.</div>
                        </motion.div>
                    </div>
                </div>

                {/* Big outlined bg text */}
                <div className="pointer-events-none absolute -bottom-6 md:-bottom-12 left-0 w-full overflow-hidden select-none">
                    <div className="pz-scroll-x font-serif-display italic text-[120px] md:text-[220px] leading-none pz-outlined whitespace-nowrap">
                        Poster.Zone · Poster.Zone · Poster.Zone ·&nbsp;
                        Poster.Zone · Poster.Zone · Poster.Zone ·&nbsp;
                    </div>
                </div>
            </section>

            {/* Marquee */}
            <div className="marquee-strip" data-testid="home-marquee">
                <Marquee gradient={false} speed={40} pauseOnHover>
                    <span className="item">Free shipping over ₹999</span>
                    <span className="item dot">✦</span>
                    <span className="item">Museum-grade paper</span>
                    <span className="item dot">✦</span>
                    <span className="item">Hand-packed with care</span>
                    <span className="item dot">✦</span>
                    <span className="item">100-year archival ink</span>
                    <span className="item dot">✦</span>
                    <span className="item">Ships worldwide</span>
                    <span className="item dot">✦</span>
                </Marquee>
            </div>

            {/* Featured Grid — Bento */}
            <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-24">
                <div className="flex items-end justify-between mb-12">
                    <Reveal>
                        <div className="eyebrow mb-3">Featured Prints</div>
                        <h2 className="font-serif-display text-5xl lg:text-6xl tracking-tighter">This week on the wall.</h2>
                    </Reveal>
                    <Reveal delay={0.15}>
                        <Link data-testid="featured-view-all" to="/shop" className="hidden md:inline-flex items-center gap-2 text-sm tracking-widest uppercase link-underline">
                            View all <ArrowRight className="w-4 h-4 hover-arrow" />
                        </Link>
                    </Reveal>
                </div>

                <StaggerContainer stagger={0.08} data-testid="featured-grid" className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6" >
                    {grid.map((p, i) => (
                        <PosterCard
                            key={p.id}
                            poster={p}
                            tall={i === 0}
                            testId={`featured-poster-${p.slug}`}
                            className={i === 0 ? "row-span-2 col-span-2" : ""}
                        />
                    ))}
                </StaggerContainer>
            </section>

            {/* Categories */}
            <section className="pz-noise-dark text-white py-24 relative overflow-hidden">
                {/* Big blurred glow */}
                <div className="absolute -top-40 -left-40 w-[600px] h-[600px] rounded-full bg-[#FF3B30] opacity-10 blur-3xl pointer-events-none" />
                <div className="absolute -bottom-40 -right-40 w-[600px] h-[600px] rounded-full bg-blue-500 opacity-10 blur-3xl pointer-events-none" />

                <div className="max-w-[1400px] mx-auto px-6 lg:px-10 relative">
                    <Reveal>
                        <div className="eyebrow text-white/50 mb-3">Explore</div>
                        <h2 className="font-serif-display text-5xl lg:text-6xl tracking-tighter mb-16">By category.</h2>
                    </Reveal>

                    <StaggerContainer stagger={0.06} data-testid="category-list" className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-x-6 gap-y-2 md:gap-y-4" >
                        {categories.map((c) => (
                            <StaggerChild key={c.name}>
                                <Link
                                    data-testid={`category-link-${c.name}`}
                                    to={`/shop?category=${encodeURIComponent(c.name)}`}
                                    className="group flex items-center justify-between py-4 border-b border-white/10 hover:border-[#FF3B30] transition"
                                >
                                    <span className="font-serif-display text-2xl italic group-hover:text-[#FF3B30] transition-colors">{c.name}</span>
                                    <span className="flex items-center gap-2 text-xs text-white/50 group-hover:text-white">
                                        {c.count} <ArrowUpRight className="w-3 h-3 hover-arrow" />
                                    </span>
                                </Link>
                            </StaggerChild>
                        ))}
                    </StaggerContainer>
                </div>
            </section>

            {/* Editorial split */}
            <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-24 grid lg:grid-cols-2 gap-16 items-center">
                <Reveal>
                    <div className="eyebrow mb-4">Craft</div>
                    <h2 className="font-serif-display text-5xl lg:text-6xl tracking-tighter leading-[0.95]">Printed on paper<br />worthy of the art.</h2>
                    <p className="mt-6 text-pz-muted leading-relaxed max-w-lg">
                        Every Poster Zone print is produced on 200-gsm matte archival stock, using giclée pigments that resist fade for 100+ years. Then hand-inspected, tube-shipped, and delivered to your door.
                    </p>
                    <Link data-testid="craft-shop-cta" to="/shop" className="pz-btn mt-8">
                        Shop all prints <ArrowRight className="w-4 h-4 hover-arrow" />
                    </Link>
                </Reveal>
                <Reveal delay={0.15}>
                    <div className="aspect-[4/5] overflow-hidden bg-pz-surface relative">
                        <motion.img
                            src="https://images.unsplash.com/photo-1695634183934-eeb0e7688f6d?auto=format&fit=crop&w=1000&q=80"
                            alt="Poster on a modern wall"
                            className="w-full h-full object-cover"
                            initial={{ scale: 1.1 }}
                            whileInView={{ scale: 1 }}
                            viewport={{ once: true }}
                            transition={{ duration: 1.4, ease: [0.2, 0.7, 0.2, 1] }}
                        />
                    </div>
                </Reveal>
            </section>
        </div>
    );
}
