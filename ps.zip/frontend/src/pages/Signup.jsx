import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";

export default function Signup() {
    const { signup } = useAuth();
    const nav = useNavigate();
    const [form, setForm] = useState({ name: "", email: "", password: "" });
    const [loading, setLoading] = useState(false);

    const update = (k) => (e) => setForm({ ...form, [k]: e.target.value });

    const submit = async (e) => {
        e.preventDefault();
        if (form.password.length < 6) return toast.error("Password must be at least 6 characters");
        setLoading(true);
        try {
            const u = await signup(form.email, form.password, form.name);
            toast.success(`Welcome, ${u.name}`);
            nav("/account");
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Signup failed");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="max-w-[440px] mx-auto px-6 py-16 lg:py-24" data-testid="signup-page">
            <div className="eyebrow mb-3">Create account</div>
            <h1 className="font-serif-display text-5xl tracking-tighter">Join Poster Zone.</h1>
            <form onSubmit={submit} className="space-y-6 mt-10">
                <label className="block">
                    <div className="eyebrow mb-1">Name</div>
                    <input data-testid="signup-name" required value={form.name} onChange={update("name")}
                        className="w-full border-b border-pz-ink py-2 bg-transparent outline-none focus:border-[#FF3B30]" />
                </label>
                <label className="block">
                    <div className="eyebrow mb-1">Email</div>
                    <input data-testid="signup-email" type="email" required value={form.email} onChange={update("email")}
                        className="w-full border-b border-pz-ink py-2 bg-transparent outline-none focus:border-[#FF3B30]" />
                </label>
                <label className="block">
                    <div className="eyebrow mb-1">Password</div>
                    <input data-testid="signup-password" type="password" required value={form.password} onChange={update("password")}
                        className="w-full border-b border-pz-ink py-2 bg-transparent outline-none focus:border-[#FF3B30]" />
                </label>
                <button data-testid="signup-submit" disabled={loading} className="pz-btn w-full">
                    {loading ? "Creating…" : "Create account"}
                </button>
            </form>
            <p className="text-sm text-pz-muted mt-6">
                Already have an account? <Link data-testid="signup-to-login" to="/login" className="text-pz-ink underline">Sign in</Link>
            </p>
        </div>
    );
}
