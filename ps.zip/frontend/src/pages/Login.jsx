import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";

// REMINDER: DO NOT HARDCODE THE URL, OR ADD ANY FALLBACKS OR REDIRECT URLS, THIS BREAKS THE AUTH
const startGoogle = () => {
    const redirectUrl = window.location.origin + "/auth/callback";
    window.location.href = `https://auth.emergentagent.com/?redirect=${encodeURIComponent(redirectUrl)}`;
};

export default function Login() {
    const { login } = useAuth();
    const nav = useNavigate();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [loading, setLoading] = useState(false);

    const submit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            const u = await login(email, password);
            toast.success(`Welcome back, ${u.name}`);
            nav(u.role === "admin" ? "/admin" : "/account");
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Login failed");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="max-w-[440px] mx-auto px-6 py-16 lg:py-24" data-testid="login-page">
            <div className="eyebrow mb-3">Welcome back</div>
            <h1 className="font-serif-display text-5xl tracking-tighter">Sign in<span className="text-[#FF3B30]">.</span></h1>

            <button data-testid="login-google-btn" onClick={startGoogle} className="pz-btn pz-btn-outline w-full mt-10 gap-3">
                <span className="text-lg leading-none">G</span> Continue with Google
            </button>

            <div className="flex items-center gap-4 my-8">
                <div className="hairline flex-1" />
                <div className="text-xs text-pz-muted uppercase tracking-widest">or</div>
                <div className="hairline flex-1" />
            </div>

            <form onSubmit={submit} className="space-y-6">
                <label className="block">
                    <div className="eyebrow mb-1">Email</div>
                    <input data-testid="login-email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
                        className="w-full border-b border-pz-ink py-2 bg-transparent outline-none focus:border-[#FF3B30]" />
                </label>
                <label className="block">
                    <div className="eyebrow mb-1">Password</div>
                    <input data-testid="login-password" type="password" required value={password} onChange={(e) => setPassword(e.target.value)}
                        className="w-full border-b border-pz-ink py-2 bg-transparent outline-none focus:border-[#FF3B30]" />
                </label>
                <button data-testid="login-submit" disabled={loading} className="pz-btn w-full">
                    {loading ? "Signing in…" : "Sign in"}
                </button>
            </form>

            <p className="text-sm text-pz-muted mt-6">
                No account? <Link data-testid="login-to-signup" to="/signup" className="text-pz-ink underline">Create one</Link>
            </p>
            <p className="text-xs text-pz-muted mt-3">
                <Link data-testid="login-to-admin" to="/admin/login" className="hover:text-pz-ink">Admin login →</Link>
            </p>
        </div>
    );
}
