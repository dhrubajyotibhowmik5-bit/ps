import React, { useEffect, useState } from "react";
import { Link, Navigate } from "react-router-dom";
import { api, formatPrice } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";

export default function Account() {
    const { user, loading } = useAuth();
    const [orders, setOrders] = useState([]);
    const [ordersLoading, setOrdersLoading] = useState(true);

    useEffect(() => {
        if (!user) return;
        api.get("/orders/mine").then((r) => setOrders(r.data)).catch(() => setOrders([])).finally(() => setOrdersLoading(false));
    }, [user]);

    if (loading) return <div className="p-16 text-pz-muted" data-testid="account-loading">Loading…</div>;
    if (!user) return <Navigate to="/login" replace />;

    return (
        <div className="max-w-[1200px] mx-auto px-6 lg:px-10 py-16" data-testid="account-page">
            <div className="mb-10 flex justify-between items-end">
                <div>
                    <div className="eyebrow mb-3">Account</div>
                    <h1 className="font-serif-display text-5xl lg:text-6xl tracking-tighter">Hi, {user.name.split(" ")[0]}<span className="text-[#FF3B30]">.</span></h1>
                    <p className="text-pz-muted mt-2">{user.email}</p>
                </div>
                {user.role === "admin" && <Link to="/admin" className="pz-btn pz-btn-outline">Admin dashboard</Link>}
            </div>

            <h2 className="eyebrow mb-4">Your Orders</h2>
            {ordersLoading ? (
                <div className="text-pz-muted">Loading orders…</div>
            ) : orders.length === 0 ? (
                <div className="border border-dashed border-pz-border p-10 text-center" data-testid="account-no-orders">
                    <div className="font-serif-display text-2xl italic">No orders yet.</div>
                    <Link to="/shop" className="pz-btn mt-4 inline-flex">Shop now</Link>
                </div>
            ) : (
                <div className="space-y-4" data-testid="account-orders-list">
                    {orders.map((o) => (
                        <Link key={o.order_id} to={`/order/${o.order_id}`} className="block border border-pz-border p-6 hover:border-pz-ink transition" data-testid={`account-order-${o.order_id}`}>
                            <div className="flex justify-between items-start flex-wrap gap-2">
                                <div>
                                    <div className="font-medium">{o.order_id}</div>
                                    <div className="text-xs text-pz-muted mt-1">{new Date(o.created_at).toLocaleString()}</div>
                                </div>
                                <div className="text-right">
                                    <div className="font-medium">{formatPrice(o.total)}</div>
                                    <div className="text-xs mt-1"><StatusBadge s={o.status} /></div>
                                </div>
                            </div>
                            <div className="mt-3 flex gap-2 overflow-x-auto">
                                {o.items.map((it, idx) => (
                                    <div key={idx} className="w-14 h-16 bg-pz-surface overflow-hidden shrink-0">
                                        <img src={it.image_url} alt="" className="w-full h-full object-cover" />
                                    </div>
                                ))}
                            </div>
                        </Link>
                    ))}
                </div>
            )}
        </div>
    );
}

function StatusBadge({ s }) {
    const map = {
        pending_payment: ["bg-yellow-100 text-yellow-800", "Pending payment"],
        placed: ["bg-black text-white", "Placed"],
        processing: ["bg-blue-100 text-blue-800", "Processing"],
        shipped: ["bg-emerald-100 text-emerald-900", "Shipped"],
        delivered: ["bg-emerald-600 text-white", "Delivered"],
        cancelled: ["bg-red-100 text-red-800", "Cancelled"],
    };
    const [cls, label] = map[s] || ["bg-pz-surface text-pz-ink", s];
    return <span className={`inline-block px-2 py-1 text-[10px] tracking-widest uppercase ${cls}`}>{label}</span>;
}
