import React from "react";
import { Link } from "react-router-dom";
import { XCircle } from "lucide-react";

export default function PaymentCancel() {
    return (
        <div className="max-w-[800px] mx-auto px-6 py-24 text-center" data-testid="payment-cancel-page">
            <XCircle className="w-14 h-14 mx-auto text-pz-muted" />
            <h1 className="mt-6 font-serif-display text-4xl italic">Payment cancelled.</h1>
            <p className="mt-2 text-pz-muted">No charge was made. Your cart is still saved.</p>
            <div className="mt-8 flex gap-3 justify-center">
                <Link to="/checkout" className="pz-btn">Back to checkout</Link>
                <Link to="/shop" className="pz-btn pz-btn-outline">Continue shopping</Link>
            </div>
        </div>
    );
}
