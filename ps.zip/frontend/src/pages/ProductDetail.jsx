import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { api, formatPrice } from "@/lib/api";
import PosterCard from "@/components/PosterCard";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import { ArrowRight, Truck, Package, ShieldCheck, Heart } from "lucide-react";
import { toast } from "sonner";

export default function ProductDetail() {
    const { slug } = useParams();
    const { addItem } = useCart();
    const { has: hasWish, toggle: toggleWish } = useWishlist();
    const [poster, setPoster] = useState(null);
    const [size, setSize] = useState(null);
    const [qty, setQty] = useState(1);
    const [related, setRelated] = useState([]);

    useEffect(() => {
        api.get(`/posters/${slug}`).then((r) => {
            setPoster(r.data);
            setSize(r.data.sizes?.[0] || null);
        });
    }, [slug]);

    useEffect(() => {
        if (!poster) return;
        api.get("/posters", { params: { category: poster.category } }).then((r) => {
            setRelated(r.data.filter((p) => p.slug !== poster.slug).slice(0, 4));
        });
    }, [poster]);

    if (!poster) {
        return <div className="max-w-[1400px] mx-auto p-10 text-pz-muted" data-testid="pdp-loading">Loading…</div>;
    }

    const unitPrice = poster.price + (size?.price_delta || 0);

    const onAddToCart = () => {
        if (!size) return;
        addItem({
            poster_id: poster.id,
            title: poster.title,
            image_url: poster.image_url,
            size: size.label,
            frame: "",
            quantity: qty,
            unit_price: unitPrice,
        });
        toast.success("Added to cart", { description: `${poster.title} · ${size.label}` });
    };

    return (
        <div data-testid="pdp-page" className="max-w-[1400px] mx-auto px-6 lg:px-10 py-12 lg:py-16">
            {/* Breadcrumb */}
            <div className="text-xs tracking-widest uppercase text-pz-muted mb-8">
                <Link to="/shop" className="hover:text-pz-ink">Shop</Link> / <Link to={`/shop?category=${poster.category}`} className="hover:text-pz-ink">{poster.category}</Link> / <span className="text-pz-ink">{poster.title}</span>
            </div>

            <div className="grid lg:grid-cols-12 gap-10 lg:gap-16">
                {/* Sticky image */}
                <div className="lg:col-span-7">
                    <div className="aspect-[4/5] bg-pz-surface overflow-hidden">
                        <img src={poster.image_url} alt={poster.title} className="w-full h-full object-cover" data-testid="pdp-main-image" />
                    </div>
                    <div className="grid grid-cols-3 gap-3 mt-3">
                        {[0, 1, 2].map((i) => (
                            <div key={i} className="aspect-square bg-pz-surface overflow-hidden">
                                <img src={poster.image_url} alt="" className="w-full h-full object-cover" />
                            </div>
                        ))}
                    </div>
                </div>

                {/* Info */}
                <div className="lg:col-span-5 lg:sticky lg:top-24 self-start">
                    <div className="eyebrow mb-3">{poster.category}</div>
                    <h1 data-testid="pdp-title" className="font-serif-display text-5xl lg:text-6xl tracking-tighter leading-[0.95]">{poster.title}</h1>
                    <div data-testid="pdp-price" className="mt-4 text-2xl font-medium tracking-tight">{formatPrice(unitPrice)}</div>
                    <p className="mt-6 text-pz-muted leading-relaxed">{poster.description}</p>

                    {/* Size selector */}
                    <div className="mt-8">
                        <div className="eyebrow mb-3">Size</div>
                        <div className="flex flex-wrap gap-2" data-testid="pdp-sizes">
                            {poster.sizes.map((s) => (
                                <button
                                    key={s.label}
                                    data-testid={`pdp-size-${s.label}`}
                                    onClick={() => setSize(s)}
                                    className={`px-4 py-2 border text-sm ${size?.label === s.label ? "border-pz-ink bg-pz-ink text-white" : "border-pz-border hover:border-pz-ink"}`}
                                >
                                    {s.label}{s.price_delta > 0 && <span className="ml-1 text-xs opacity-70">+{formatPrice(s.price_delta)}</span>}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Qty + Add */}
                    <div className="mt-8 flex items-center gap-4">
                        <div className="flex items-center border border-pz-ink">
                            <button data-testid="pdp-qty-dec" onClick={() => setQty(Math.max(1, qty - 1))} className="px-3 py-2 hover:bg-pz-surface">−</button>
                            <span data-testid="pdp-qty" className="px-4 text-sm">{qty}</span>
                            <button data-testid="pdp-qty-inc" onClick={() => setQty(qty + 1)} className="px-3 py-2 hover:bg-pz-surface">+</button>
                        </div>
                        <button data-testid="pdp-add-to-cart" onClick={onAddToCart} className="pz-btn flex-1">
                            Add to cart <ArrowRight className="w-4 h-4 hover-arrow" />
                        </button>
                        <button
                            data-testid="pdp-wishlist-btn"
                            onClick={() => toggleWish(poster.id)}
                            aria-pressed={hasWish(poster.id)}
                            aria-label={hasWish(poster.id) ? "Remove from wishlist" : "Save to wishlist"}
                            className={`h-11 w-11 border flex items-center justify-center transition ${hasWish(poster.id) ? "bg-[#FF3B30] border-[#FF3B30] text-white" : "border-pz-ink hover:bg-pz-ink hover:text-white"}`}
                        >
                            <Heart className="w-5 h-5" fill={hasWish(poster.id) ? "#fff" : "transparent"} strokeWidth={hasWish(poster.id) ? 0 : 1.8} />
                        </button>
                    </div>

                    {/* Reassurance */}
                    <div className="mt-10 grid grid-cols-3 gap-4 pt-6 border-t border-pz-border">
                        <div className="text-xs">
                            <Truck className="w-5 h-5 mb-2" />
                            <div className="font-medium">Free over ₹999</div>
                            <div className="text-pz-muted">India-wide</div>
                        </div>
                        <div className="text-xs">
                            <Package className="w-5 h-5 mb-2" />
                            <div className="font-medium">Tube shipped</div>
                            <div className="text-pz-muted">Crease-free</div>
                        </div>
                        <div className="text-xs">
                            <ShieldCheck className="w-5 h-5 mb-2" />
                            <div className="font-medium">100-yr fade</div>
                            <div className="text-pz-muted">Archival ink</div>
                        </div>
                    </div>
                </div>
            </div>

            {related.length > 0 && (
                <section className="mt-24">
                    <div className="eyebrow mb-3">You may also love</div>
                    <h2 className="font-serif-display text-4xl lg:text-5xl tracking-tighter mb-10">More in {poster.category}.</h2>
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
                        {related.map((p) => <PosterCard key={p.id} poster={p} testId={`related-poster-${p.slug}`} />)}
                    </div>
                </section>
            )}
        </div>
    );
}
