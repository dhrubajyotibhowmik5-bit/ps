import React, { useEffect, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { api } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";

export default function AuthCallback() {
    const location = useLocation();
    const nav = useNavigate();
    const { setUser } = useAuth();
    const hasProcessed = useRef(false);

    useEffect(() => {
        if (hasProcessed.current) return;
        hasProcessed.current = true;
        const hash = location.hash || "";
        const match = hash.match(/session_id=([^&]+)/);
        if (!match) {
            nav("/login");
            return;
        }
        const sessionId = decodeURIComponent(match[1]);
        (async () => {
            try {
                const { data } = await api.post("/auth/google/session", { session_id: sessionId });
                setUser(data.user);
                // Clean the hash
                window.history.replaceState(null, "", window.location.pathname);
                nav(data.user.role === "admin" ? "/admin" : "/account", { state: { user: data.user } });
            } catch (e) {
                nav("/login");
            }
        })();
    }, [location.hash, nav, setUser]);

    return (
        <div className="max-w-[600px] mx-auto py-24 text-center" data-testid="auth-callback">
            <div className="font-serif-display text-4xl italic">Signing you in…</div>
            <p className="text-pz-muted mt-2">One moment.</p>
        </div>
    );
}
