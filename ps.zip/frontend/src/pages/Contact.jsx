import React, { useState } from "react";
import { toast } from "sonner";

export default function Contact() {
    const [sent, setSent] = useState(false);
    return (
        <div className="max-w-[900px] mx-auto px-6 py-16 lg:py-24" data-testid="contact-page">
            <div className="eyebrow mb-3">Contact</div>
            <h1 className="font-serif-display text-5xl lg:text-6xl tracking-tighter">Say hello<span className="text-[#FF3B30]">.</span></h1>

            {sent ? (
                <div className="mt-12 border border-pz-border p-8" data-testid="contact-sent">
                    <div className="font-serif-display text-3xl italic">Thanks — we’ll be in touch.</div>
                    <p className="text-pz-muted mt-2">We reply within a business day.</p>
                </div>
            ) : (
                <form onSubmit={(e) => { e.preventDefault(); toast.success("Message sent"); setSent(true); }} className="mt-12 grid gap-6 max-w-xl">
                    <label className="block">
                        <div className="eyebrow mb-1">Name</div>
                        <input data-testid="contact-name" required className="w-full border-b border-pz-ink py-2 bg-transparent outline-none" />
                    </label>
                    <label className="block">
                        <div className="eyebrow mb-1">Email</div>
                        <input data-testid="contact-email" type="email" required className="w-full border-b border-pz-ink py-2 bg-transparent outline-none" />
                    </label>
                    <label className="block">
                        <div className="eyebrow mb-1">Message</div>
                        <textarea data-testid="contact-message" required rows={5} className="w-full border-b border-pz-ink py-2 bg-transparent outline-none" />
                    </label>
                    <button data-testid="contact-submit" className="pz-btn self-start">Send message</button>
                </form>
            )}

            <div className="mt-16 grid md:grid-cols-2 gap-8 text-sm">
                <div>
                    <div className="eyebrow mb-2">Support</div>
                    <div>hello@posterzone.in</div>
                </div>
                <div>
                    <div className="eyebrow mb-2">Wholesale & Bulk</div>
                    <div>bulk@posterzone.in</div>
                </div>
            </div>
        </div>
    );
}
