import React, { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { api } from "@/lib/api";
import PosterCard from "@/components/PosterCard";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { StaggerContainer, Reveal } from "@/components/motion";

const SORT_OPTS = [
    { value: "featured", label: "Featured" },
    { value: "price_asc", label: "Price: Low → High" },
    { value: "price_desc", label: "Price: High → Low" },
    { value: "newest", label: "Newest" },
];

export default function Shop() {
    const [params, setParams] = useSearchParams();
    const category = params.get("category") || "all";
    const q = params.get("q") || "";
    const sort = params.get("sort") || "featured";

    const [posters, setPosters] = useState([]);
    const [categories, setCategories] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        api.get("/posters/categories").then((r) => setCategories(r.data));
    }, []);

    useEffect(() => {
        setLoading(true);
        const p = {};
        if (category !== "all") p.category = category;
        if (q) p.q = q;
        api.get("/posters", { params: p }).then((r) => {
            setPosters(r.data);
            setLoading(false);
        });
    }, [category, q]);

    const setCategory = (name) => {
        const next = new URLSearchParams(params);
        if (name === "all") next.delete("category");
        else next.set("category", name);
        setParams(next);
    };

    const setSort = (s) => {
        const next = new URLSearchParams(params);
        next.set("sort", s);
        setParams(next);
    };

    const sorted = useMemo(() => {
        const arr = [...posters];
        if (sort === "price_asc") arr.sort((a, b) => a.price - b.price);
        else if (sort === "price_desc") arr.sort((a, b) => b.price - a.price);
        else if (sort === "newest") arr.sort((a, b) => (b.created_at || "").localeCompare(a.created_at || ""));
        else arr.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
        return arr;
    }, [posters, sort]);

    return (
        <div data-testid="shop-page" className="max-w-[1400px] mx-auto px-6 lg:px-10 py-12 lg:py-16">
            <Reveal className="mb-12">
                <div className="eyebrow mb-3">Shop</div>
                <h1 className="font-serif-display text-5xl lg:text-7xl tracking-tighter">
                    {category === "all" ? "All prints." : <>{category}<span className="text-[#FF3B30]">.</span></>}
                </h1>
                {q && <p className="mt-3 text-pz-muted">Search results for “{q}”</p>}
            </Reveal>

            <div className="grid lg:grid-cols-12 gap-8 lg:gap-12">
                {/* Sidebar */}
                <aside className="lg:col-span-3 space-y-8" data-testid="shop-filters">
                    <div>
                        <div className="eyebrow mb-4">Categories</div>
                        <ul className="space-y-2">
                            <li>
                                <button
                                    data-testid="filter-cat-all"
                                    onClick={() => setCategory("all")}
                                    className={`text-sm hover:text-[#FF3B30] ${category === "all" ? "text-[#FF3B30] font-medium" : ""}`}
                                >
                                    All ({posters.length && category === "all" ? posters.length : categories.reduce((s, c) => s + c.count, 0)})
                                </button>
                            </li>
                            {categories.map((c) => (
                                <li key={c.name}>
                                    <button
                                        data-testid={`filter-cat-${c.name}`}
                                        onClick={() => setCategory(c.name)}
                                        className={`text-sm hover:text-[#FF3B30] ${category === c.name ? "text-[#FF3B30] font-medium" : ""}`}
                                    >
                                        {c.name} <span className="text-pz-muted">({c.count})</span>
                                    </button>
                                </li>
                            ))}
                        </ul>
                    </div>

                    <Accordion type="multiple" defaultValue={["price", "size"]}>
                        <AccordionItem value="price">
                            <AccordionTrigger className="eyebrow">Price</AccordionTrigger>
                            <AccordionContent className="text-sm text-pz-muted">
                                Prints from ₹189. Choose your size to see final price.
                            </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="size">
                            <AccordionTrigger className="eyebrow">Size</AccordionTrigger>
                            <AccordionContent className="text-sm text-pz-muted space-y-1">
                                <div>A4 · 8″×11″</div>
                                <div>A3 · 12″×17″</div>
                                <div>A2 · 17″×23″</div>
                            </AccordionContent>
                        </AccordionItem>
                    </Accordion>
                </aside>

                {/* Grid */}
                <main className="lg:col-span-9">
                    <div className="flex justify-between items-center mb-8 pb-4 border-b border-pz-border">
                        <div className="text-sm text-pz-muted">{sorted.length} prints</div>
                        <select
                            data-testid="shop-sort"
                            value={sort}
                            onChange={(e) => setSort(e.target.value)}
                            className="bg-transparent text-sm border-b border-pz-ink pb-1 outline-none"
                        >
                            {SORT_OPTS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                        </select>
                    </div>

                    {loading ? (
                        <div className="text-center py-20 text-pz-muted" data-testid="shop-loading">Loading prints…</div>
                    ) : sorted.length === 0 ? (
                        <div className="text-center py-20" data-testid="shop-empty">
                            <div className="font-serif-display text-3xl italic">No prints found.</div>
                            <p className="text-pz-muted mt-2">Try a different filter.</p>
                        </div>
                    ) : (
                        <StaggerContainer stagger={0.06} data-testid="shop-grid" className="grid grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6" >
                            {sorted.map((p) => <PosterCard key={p.id} poster={p} testId={`shop-poster-${p.slug}`} />)}
                        </StaggerContainer>
                    )}
                </main>
            </div>
        </div>
    );
}
