import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { api, formatPrice } from "@/lib/api";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import { Smartphone, ShieldCheck } from "lucide-react";

const UPI_ID = "dhrubajyotibhowmik5@oksbi";
const UPI_NAME = "Dhrubajyoti Bhowmik";

export default function Checkout() {
    const { items, subtotal, shipping, total, count } = useCart();
    const { user } = useAuth();
    const nav = useNavigate();
    const [loading, setLoading] = useState(false);
    const [form, setForm] = useState({
        shipping_name: user?.name || "",
        shipping_email: user?.email || "",
        shipping_phone: "",
        shipping_address: "",
        shipping_city: "",
        shipping_state: "",
        shipping_pincode: "",
    });

    const update = (k) => (e) => setForm({ ...form, [k]: e.target.value });

    if (count === 0) {
        return (
            <div className="max-w-[1000px] mx-auto px-6 py-24 text-center" data-testid="checkout-empty">
                <h1 className="font-serif-display text-5xl italic">Your cart is empty.</h1>
                <Link data-testid="checkout-empty-cta" to="/shop" className="pz-btn mt-8 inline-flex">Browse Shop</Link>
            </div>
        );
    }

    const upiUri = `upi://pay?pa=${encodeURIComponent(UPI_ID)}&pn=${encodeURIComponent(UPI_NAME)}&am=${total}&cu=INR&tn=${encodeURIComponent("Poster Zone Order")}`;

    const submit = async (e) => {
        e.preventDefault();
        for (const k of Object.keys(form)) {
            if (!form[k].trim()) {
                toast.error("Please fill all shipping details");
                return;
            }
        }
        setLoading(true);
        try {
            const payload = { items, ...form, origin_url: window.location.origin };
            const { data } = await api.post("/orders/checkout/upi", payload);
            sessionStorage.setItem("pz_last_order", data.order_id);
            nav(`/payment/upi?order_id=${data.order_id}`);
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Checkout failed");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="max-w-[1200px] mx-auto px-6 lg:px-10 py-12 lg:py-16" data-testid="checkout-page">
            <div className="mb-10">
                <div className="eyebrow mb-3">Checkout</div>
                <h1 className="font-serif-display text-5xl lg:text-6xl tracking-tighter">Almost home<span className="text-[#FF3B30]">.</span></h1>
            </div>

            <form onSubmit={submit} className="grid lg:grid-cols-12 gap-10 lg:gap-16">
                <section className="lg:col-span-7 space-y-8">
                    <div>
                        <h2 className="eyebrow mb-4">Shipping Details</h2>
                        <div className="grid grid-cols-2 gap-4">
                            <Input label="Full Name" testId="checkout-name" value={form.shipping_name} onChange={update("shipping_name")} required />
                            <Input label="Email" testId="checkout-email" type="email" value={form.shipping_email} onChange={update("shipping_email")} required />
                            <Input label="Phone" testId="checkout-phone" value={form.shipping_phone} onChange={update("shipping_phone")} required />
                            <Input label="Pincode" testId="checkout-pincode" value={form.shipping_pincode} onChange={update("shipping_pincode")} required />
                        </div>
                        <div className="mt-4"><Input label="Address" testId="checkout-address" value={form.shipping_address} onChange={update("shipping_address")} required /></div>
                        <div className="grid grid-cols-2 gap-4 mt-4">
                            <Input label="City" testId="checkout-city" value={form.shipping_city} onChange={update("shipping_city")} required />
                            <Input label="State" testId="checkout-state" value={form.shipping_state} onChange={update("shipping_state")} required />
                        </div>
                    </div>

                    <div>
                        <h2 className="eyebrow mb-4">Payment</h2>

                        <div className="border border-pz-ink p-4 flex gap-3 items-center bg-pz-surface" data-testid="pay-method-upi">
                            <Smartphone className="w-5 h-5" />
                            <div className="flex-1">
                                <div className="flex items-center gap-2 font-medium">UPI Payment
                                    <span className="text-[10px] bg-[#FF3B30] text-white px-1.5 py-0.5 rounded-sm">Instant</span>
                                </div>
                                <p className="text-xs text-pz-muted mt-0.5">GPay · PhonePe · Paytm · BHIM · any UPI app</p>
                            </div>
                            <ShieldCheck className="w-5 h-5 text-emerald-600" />
                        </div>

                        <div className="mt-4 border border-pz-border p-6 bg-pz-surface" data-testid="upi-preview">
                            <div className="flex flex-col md:flex-row gap-6 items-center">
                                <img src="/upi-qr.jpg" alt="UPI QR code" className="w-48 h-48 object-contain bg-white border border-pz-border p-2" data-testid="upi-qr-preview" />
                                <div className="flex-1 text-sm">
                                    <div className="eyebrow mb-1">Pay to</div>
                                    <div className="font-serif-display text-2xl">{UPI_NAME}</div>
                                    <div className="mt-3 eyebrow">UPI ID</div>
                                    <div className="font-mono text-sm mt-1 select-all">{UPI_ID}</div>
                                    <div className="mt-4 eyebrow">Amount</div>
                                    <div className="font-serif-display text-3xl text-[#FF3B30]">{formatPrice(total)}</div>
                                    <a href={upiUri} className="pz-btn mt-4 inline-flex md:hidden text-xs" data-testid="upi-open-app-mobile">Open in UPI app</a>
                                </div>
                            </div>
                            <p className="mt-4 text-xs text-pz-muted">
                                After placing the order below, scan this QR (or use the UPI ID) with your UPI app.
                                Once we confirm your payment, we'll dispatch your order — usually within 24 hours.
                            </p>
                        </div>
                    </div>
                </section>

                <aside className="lg:col-span-5 bg-pz-surface p-8 lg:sticky lg:top-24 self-start">
                    <h2 className="eyebrow mb-6">Order Summary</h2>
                    <div className="space-y-4 mb-6 max-h-[300px] overflow-y-auto" data-testid="checkout-items">
                        {items.map((i) => (
                            <div key={`${i.poster_id}-${i.size}-${i.frame}`} className="flex gap-3">
                                <div className="w-14 h-16 bg-white overflow-hidden shrink-0">
                                    <img src={i.image_url} alt="" className="w-full h-full object-cover" />
                                </div>
                                <div className="flex-1 min-w-0 text-sm">
                                    <div className="font-medium truncate">{i.title}</div>
                                    <div className="text-xs text-pz-muted">{i.size} × {i.quantity}</div>
                                </div>
                                <div className="text-sm font-medium">{formatPrice(i.unit_price * i.quantity)}</div>
                            </div>
                        ))}
                    </div>
                    <div className="border-t border-pz-border pt-4 space-y-2 text-sm">
                        <div className="flex justify-between"><span className="text-pz-muted">Subtotal</span><span data-testid="checkout-subtotal">{formatPrice(subtotal)}</span></div>
                        <div className="flex justify-between"><span className="text-pz-muted">Shipping</span><span data-testid="checkout-shipping">{shipping === 0 ? "Free" : formatPrice(shipping)}</span></div>
                        <div className="flex justify-between text-lg font-medium pt-2 border-t border-pz-border"><span>Total</span><span data-testid="checkout-total">{formatPrice(total)}</span></div>
                    </div>
                    <button data-testid="checkout-pay-btn" disabled={loading} className="pz-btn w-full mt-6">
                        {loading ? "Placing order…" : "Place order & pay by UPI"}
                    </button>
                    <p className="text-[11px] text-pz-muted text-center mt-3">You'll see the QR again on the next screen with instructions.</p>
                </aside>
            </form>
        </div>
    );
}

function Input({ label, testId, ...rest }) {
    return (
        <label className="block">
            <div className="eyebrow mb-1">{label}</div>
            <input data-testid={testId} {...rest} className="w-full bg-transparent border-b border-pz-ink py-2 outline-none focus:border-[#FF3B30] transition" />
        </label>
    );
}
