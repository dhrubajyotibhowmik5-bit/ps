import React from "react";
import { Link } from "react-router-dom";
import { Heart } from "lucide-react";
import { useWishlist } from "@/context/WishlistContext";
import { useAuth } from "@/context/AuthContext";
import PosterCard from "@/components/PosterCard";

export default function Wishlist() {
    const { items, ids, loading } = useWishlist();
    const { user } = useAuth();

    // Guests: we have only ids in localStorage, not full posters. Show a login prompt.
    const showLoginNudge = !user && ids.length > 0;

    return (
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-16" data-testid="wishlist-page">
            <div className="mb-10">
                <div className="eyebrow mb-3">Saved for later</div>
                <h1 className="font-serif-display text-5xl lg:text-6xl tracking-tighter flex items-center gap-4">
                    Your wishlist
                    <Heart className="w-8 h-8 text-[#FF3B30]" fill="#FF3B30" strokeWidth={0} />
                </h1>
            </div>

            {loading && <div className="text-pz-muted" data-testid="wishlist-loading">Loading…</div>}

            {!loading && ids.length === 0 && (
                <div className="border border-dashed border-pz-border p-16 text-center" data-testid="wishlist-empty">
                    <Heart className="w-10 h-10 mx-auto text-pz-muted mb-4" strokeWidth={1.5} />
                    <div className="font-serif-display text-3xl italic">Nothing saved yet.</div>
                    <p className="text-pz-muted mt-2">Tap the heart on any poster to save it here.</p>
                    <Link data-testid="wishlist-empty-cta" to="/shop" className="pz-btn mt-6 inline-flex">Browse Shop</Link>
                </div>
            )}

            {!loading && showLoginNudge && (
                <div className="border border-pz-border p-8 mb-8" data-testid="wishlist-login-nudge">
                    <div className="font-serif-display text-2xl italic">You have {ids.length} saved {ids.length === 1 ? "poster" : "posters"} on this device.</div>
                    <p className="text-pz-muted text-sm mt-2">Sign in to sync your wishlist across all devices.</p>
                    <div className="mt-4 flex gap-3">
                        <Link to="/login" className="pz-btn">Sign in</Link>
                        <Link to="/signup" className="pz-btn pz-btn-outline">Create account</Link>
                    </div>
                </div>
            )}

            {!loading && user && items.length > 0 && (
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6" data-testid="wishlist-grid">
                    {items.map((p) => <PosterCard key={p.id} poster={p} testId={`wishlist-poster-${p.slug}`} />)}
                </div>
            )}
        </div>
    );
}
