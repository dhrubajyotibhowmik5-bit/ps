import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { api, formatPrice } from "@/lib/api";

export default function OrderDetail() {
    const { orderId } = useParams();
    const [order, setOrder] = useState(null);
    const [notFound, setNotFound] = useState(false);

    useEffect(() => {
        api.get(`/orders/${orderId}`).then((r) => setOrder(r.data)).catch(() => setNotFound(true));
    }, [orderId]);

    if (notFound) {
        return <div className="max-w-[800px] mx-auto p-16 text-center" data-testid="order-not-found">
            <h1 className="font-serif-display text-4xl italic">Order not found.</h1>
            <Link to="/shop" className="pz-btn mt-6 inline-flex">Back to shop</Link>
        </div>;
    }
    if (!order) return <div className="p-16 text-pz-muted">Loading order…</div>;

    return (
        <div className="max-w-[900px] mx-auto px-6 py-16" data-testid="order-detail-page">
            <div className="eyebrow mb-3">Order</div>
            <h1 className="font-serif-display text-5xl tracking-tighter" data-testid="order-id">{order.order_id}</h1>
            <p className="text-pz-muted mt-2">Placed {new Date(order.created_at).toLocaleString()}</p>

            <div className="mt-8 border border-pz-border">
                <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-pz-border">
                    <Cell label="Status" value={order.status} testId="order-status" />
                    <Cell label="Payment" value={order.payment_status} testId="order-payment-status" />
                    <Cell label="Items" value={order.items.length} />
                    <Cell label="Total" value={formatPrice(order.total)} testId="order-total" />
                </div>
            </div>

            <h2 className="eyebrow mt-10 mb-4">Items</h2>
            <div className="space-y-4">
                {order.items.map((i, idx) => (
                    <div key={idx} className="flex gap-4 border border-pz-border p-4">
                        <div className="w-16 h-20 bg-pz-surface overflow-hidden">
                            <img src={i.image_url} alt="" className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-1">
                            <div className="font-medium">{i.title}</div>
                            <div className="text-xs text-pz-muted mt-1">{i.size} × {i.quantity}</div>
                        </div>
                        <div className="font-medium">{formatPrice(i.unit_price * i.quantity)}</div>
                    </div>
                ))}
            </div>

            <h2 className="eyebrow mt-10 mb-4">Shipping</h2>
            <div className="border border-pz-border p-6 text-sm space-y-1">
                <div className="font-medium">{order.shipping_address?.name}</div>
                <div>{order.shipping_address?.address}</div>
                <div>{order.shipping_address?.city}, {order.shipping_address?.state} {order.shipping_address?.pincode}</div>
                <div className="text-pz-muted">{order.shipping_address?.phone} · {order.shipping_address?.email}</div>
            </div>
        </div>
    );
}

function Cell({ label, value, testId }) {
    return (
        <div className="p-4">
            <div className="eyebrow mb-1">{label}</div>
            <div className="text-sm capitalize" data-testid={testId}>{String(value).replace(/_/g, " ")}</div>
        </div>
    );
}
