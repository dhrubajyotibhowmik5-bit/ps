import React, { useState, useEffect } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { Lock, Shield } from "lucide-react";
import { toast } from "sonner";

export default function AdminLogin() {
    const { user, loading, login } = useAuth();
    const nav = useNavigate();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [submitting, setSubmitting] = useState(false);

    // Auto-redirect if already an admin
    useEffect(() => {
        if (!loading && user?.role === "admin") nav("/admin", { replace: true });
    }, [user, loading, nav]);

    if (user?.role === "admin") return <Navigate to="/admin" replace />;

    const submit = async (e) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            const u = await login(email, password);
            if (u.role !== "admin") {
                toast.error("This account does not have admin access");
                return;
            }
            toast.success(`Welcome back, ${u.name}`);
            nav("/admin", { replace: true });
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Login failed");
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <div className="min-h-[calc(100vh-80px)] flex" data-testid="admin-login-page">
            {/* Left visual */}
            <div className="hidden lg:flex lg:w-1/2 bg-pz-ink text-white items-center justify-center relative overflow-hidden">
                <img
                    src="https://images.unsplash.com/photo-1615529182904-14819c35db37?auto=format&fit=crop&w=1200&q=80"
                    alt=""
                    className="absolute inset-0 w-full h-full object-cover opacity-30"
                />
                <div className="relative z-10 p-16 max-w-md">
                    <div className="eyebrow text-white/60 mb-4">Admin console</div>
                    <h2 className="font-serif-display text-6xl tracking-tighter leading-[0.95]">
                        The<br /><span className="italic">back room</span>.
                    </h2>
                    <p className="mt-6 text-white/70 leading-relaxed">
                        Upload single or bulk posters, edit rates & sizes, and manage orders — from one clean desk.
                    </p>
                </div>
            </div>

            {/* Right form */}
            <div className="flex-1 flex items-center justify-center px-6 py-16">
                <div className="w-full max-w-md">
                    <div className="flex items-center gap-3 mb-3">
                        <Shield className="w-5 h-5 text-[#FF3B30]" />
                        <div className="eyebrow">Restricted access</div>
                    </div>
                    <h1 className="font-serif-display text-5xl tracking-tighter">Admin Login<span className="text-[#FF3B30]">.</span></h1>
                    <p className="text-pz-muted mt-3 text-sm">Sign in with your Poster Zone admin credentials.</p>

                    <form onSubmit={submit} className="space-y-6 mt-10">
                        <label className="block">
                            <div className="eyebrow mb-1">Email</div>
                            <input
                                data-testid="admin-login-email"
                                type="email"
                                required
                                autoComplete="username"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="w-full border-b border-pz-ink py-2 bg-transparent outline-none focus:border-[#FF3B30]"
                            />
                        </label>
                        <label className="block">
                            <div className="eyebrow mb-1">Password</div>
                            <input
                                data-testid="admin-login-password"
                                type="password"
                                required
                                autoComplete="current-password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="w-full border-b border-pz-ink py-2 bg-transparent outline-none focus:border-[#FF3B30]"
                            />
                        </label>
                        <button data-testid="admin-login-submit" disabled={submitting} className="pz-btn w-full gap-2">
                            <Lock className="w-4 h-4" /> {submitting ? "Signing in…" : "Enter admin console"}
                        </button>
                    </form>

                    <div className="mt-8 text-xs text-pz-muted">
                        Not an admin? <Link to="/login" className="text-pz-ink underline">Customer login</Link>
                    </div>
                </div>
            </div>
        </div>
    );
}
