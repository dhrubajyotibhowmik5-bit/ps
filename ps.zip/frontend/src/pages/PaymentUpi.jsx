import React, { useEffect, useState } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { api, formatPrice } from "@/lib/api";
import { useCart } from "@/context/CartContext";
import { Copy, Check, Clock, ArrowRight, Smartphone } from "lucide-react";
import { toast } from "sonner";

const UPI_ID = "dhrubajyotibhowmik5@oksbi";
const UPI_NAME = "Dhrubajyoti Bhowmik";

export default function PaymentUpi() {
    const [params] = useSearchParams();
    const orderId = params.get("order_id");
    const [order, setOrder] = useState(null);
    const [copied, setCopied] = useState(false);
    const { clear } = useCart();

    useEffect(() => {
        if (!orderId) return;
        api.get(`/orders/${orderId}`).then((r) => setOrder(r.data)).catch(() => {});
        // Clear cart since order is placed
        clear();
        sessionStorage.removeItem("pz_last_order");
        // eslint-disable-next-line
    }, [orderId]);

    const copy = async () => {
        try {
            await navigator.clipboard.writeText(UPI_ID);
            setCopied(true);
            toast.success("UPI ID copied");
            setTimeout(() => setCopied(false), 2000);
        } catch { toast.error("Copy failed"); }
    };

    if (!orderId) return <div className="p-16 text-center" data-testid="upi-page-error">No order found.</div>;

    const total = order?.total || 0;
    const upiUri = `upi://pay?pa=${encodeURIComponent(UPI_ID)}&pn=${encodeURIComponent(UPI_NAME)}${total ? `&am=${total}` : ""}&cu=INR&tn=${encodeURIComponent(orderId)}`;

    return (
        <div className="max-w-[900px] mx-auto px-6 py-16" data-testid="payment-upi-page">
            <div className="text-center mb-10">
                <div className="inline-flex items-center gap-2 bg-amber-50 border border-amber-200 px-3 py-1 text-xs text-amber-800 mb-4">
                    <Clock className="w-3.5 h-3.5" /> Awaiting payment
                </div>
                <h1 className="font-serif-display text-5xl lg:text-6xl tracking-tighter">Almost there<span className="text-[#FF3B30]">.</span></h1>
                <p className="text-pz-muted mt-4 max-w-xl mx-auto">
                    Your order is reserved. Scan the QR below or copy the UPI ID to pay via any UPI app. We'll verify your payment and dispatch within 24 hours.
                </p>
            </div>

            <div className="border border-pz-border p-6 md:p-10 grid md:grid-cols-2 gap-8 items-center">
                <div className="text-center">
                    <img
                        src="/upi-qr.jpg"
                        alt="UPI QR code"
                        className="w-full max-w-xs mx-auto border border-pz-border bg-white p-2"
                        data-testid="upi-qr-image"
                    />
                    <a href={upiUri} className="pz-btn mt-4 inline-flex md:hidden" data-testid="upi-open-app">
                        <Smartphone className="w-4 h-4" /> Open in UPI app
                    </a>
                </div>
                <div>
                    <div className="eyebrow mb-1">Pay to</div>
                    <div className="font-serif-display text-3xl">{UPI_NAME}</div>

                    <div className="eyebrow mt-6 mb-1">UPI ID</div>
                    <div className="flex items-center gap-2 border border-pz-border px-3 py-2">
                        <span className="font-mono text-sm flex-1" data-testid="upi-id-text">{UPI_ID}</span>
                        <button data-testid="upi-copy-btn" onClick={copy} className="text-xs flex items-center gap-1 hover:text-[#FF3B30]">
                            {copied ? <><Check className="w-3.5 h-3.5" /> Copied</> : <><Copy className="w-3.5 h-3.5" /> Copy</>}
                        </button>
                    </div>

                    <div className="eyebrow mt-6 mb-1">Order ID</div>
                    <div className="font-mono text-sm" data-testid="upi-order-id">{orderId}</div>

                    <div className="eyebrow mt-6 mb-1">Amount to pay</div>
                    <div className="font-serif-display text-4xl text-[#FF3B30]" data-testid="upi-amount">{formatPrice(total)}</div>
                </div>
            </div>

            <ol className="mt-10 grid md:grid-cols-3 gap-6">
                <Step n="01" title="Scan or copy" text="Open GPay / PhonePe / Paytm / any UPI app and scan the QR — or paste the UPI ID." />
                <Step n="02" title="Pay the amount" text={`Send exactly ${formatPrice(total)} to ${UPI_NAME}. Add the order ID as a note if possible.`} />
                <Step n="03" title="We verify" text="Once we receive your payment, you'll get a confirmation email and your order goes to production." />
            </ol>

            <div className="mt-12 flex flex-col sm:flex-row justify-center gap-3">
                <Link data-testid="upi-view-order" to={`/order/${orderId}`} className="pz-btn">
                    View order status <ArrowRight className="w-4 h-4 hover-arrow" />
                </Link>
                <Link data-testid="upi-continue-shopping" to="/shop" className="pz-btn pz-btn-outline">
                    Continue shopping
                </Link>
            </div>

            <p className="text-center text-xs text-pz-muted mt-10">
                Trouble paying? Email <a href="mailto:hello@posterzone.in" className="underline">hello@posterzone.in</a> with your order ID.
            </p>
        </div>
    );
}

function Step({ n, title, text }) {
    return (
        <div>
            <div className="font-serif-display text-4xl italic text-pz-muted">{n}</div>
            <div className="font-medium mt-2">{title}</div>
            <p className="text-sm text-pz-muted mt-1 leading-relaxed">{text}</p>
        </div>
    );
}
