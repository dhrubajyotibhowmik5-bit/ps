import React from "react";
import { Link } from "react-router-dom";

export default function About() {
    return (
        <div className="max-w-[1200px] mx-auto px-6 lg:px-10 py-16 lg:py-24" data-testid="about-page">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
                <div>
                    <div className="eyebrow mb-3">About</div>
                    <h1 className="font-serif-display text-5xl lg:text-7xl tracking-tighter leading-[0.95]">A print<br />is a small<br /><span className="italic">rebellion</span>.</h1>
                    <p className="mt-8 text-pz-muted leading-relaxed">
                        Poster Zone was born from a simple idea: the walls we live with shape how we live.
                        We hand-pick every design, print on archival stock, and ship in bulletproof tubes
                        so that your favourite film, band, quote or memory arrives just as we imagined it.
                    </p>
                    <p className="mt-4 text-pz-muted leading-relaxed">
                        From a studio in India, we ship to over 30 countries — because good art has no borders.
                    </p>
                    <div className="mt-10">
                        <Link to="/shop" className="pz-btn">Shop the collection</Link>
                    </div>
                </div>
                <div className="aspect-[4/5] bg-pz-surface overflow-hidden">
                    <img src="https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=1000&q=80" alt="" className="w-full h-full object-cover" />
                </div>
            </div>

            <div className="mt-24 grid md:grid-cols-3 gap-10 border-t border-pz-border pt-16">
                <div>
                    <div className="font-serif-display text-6xl italic">01</div>
                    <div className="eyebrow mt-2">Design</div>
                    <p className="text-pz-muted text-sm mt-3">Curated & licensed by our team. No throwaways.</p>
                </div>
                <div>
                    <div className="font-serif-display text-6xl italic">02</div>
                    <div className="eyebrow mt-2">Print</div>
                    <p className="text-pz-muted text-sm mt-3">200-gsm matte archival paper. 100-yr fade-resistant pigments.</p>
                </div>
                <div>
                    <div className="font-serif-display text-6xl italic">03</div>
                    <div className="eyebrow mt-2">Ship</div>
                    <p className="text-pz-muted text-sm mt-3">Tube shipped, crease-free, tracked. Free over ₹999.</p>
                </div>
            </div>
        </div>
    );
}
