import React, { createContext, useContext, useEffect, useMemo, useState } from "react";

const CartCtx = createContext(null);
const STORAGE_KEY = "pz_cart_v1";

const uniqKey = (posterId, size, frame) => `${posterId}::${size}::${frame}`;

export function CartProvider({ children }) {
    const [items, setItems] = useState([]);
    const [open, setOpen] = useState(false);
    const [hydrated, setHydrated] = useState(false);

    useEffect(() => {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (raw) setItems(JSON.parse(raw));
        } catch { /* ignore */ }
        setHydrated(true);
    }, []);

    useEffect(() => {
        if (!hydrated) return;
        localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    }, [items, hydrated]);

    const addItem = (item) => {
        setItems((prev) => {
            const key = uniqKey(item.poster_id, item.size, item.frame);
            const idx = prev.findIndex(
                (i) => uniqKey(i.poster_id, i.size, i.frame) === key
            );
            if (idx >= 0) {
                const next = [...prev];
                next[idx] = { ...next[idx], quantity: next[idx].quantity + item.quantity };
                return next;
            }
            return [...prev, item];
        });
        setOpen(true);
    };

    const removeItem = (posterId, size, frame) => {
        setItems((prev) => prev.filter((i) => uniqKey(i.poster_id, i.size, i.frame) !== uniqKey(posterId, size, frame)));
    };

    const updateQty = (posterId, size, frame, qty) => {
        setItems((prev) =>
            prev.map((i) =>
                uniqKey(i.poster_id, i.size, i.frame) === uniqKey(posterId, size, frame)
                    ? { ...i, quantity: Math.max(1, qty) }
                    : i
            )
        );
    };

    const clear = () => setItems([]);

    const subtotal = useMemo(
        () => items.reduce((s, i) => s + i.unit_price * i.quantity, 0),
        [items]
    );
    const count = useMemo(() => items.reduce((s, i) => s + i.quantity, 0), [items]);
    const shipping = subtotal >= 999 || subtotal === 0 ? 0 : 49;
    const total = subtotal + shipping;

    return (
        <CartCtx.Provider value={{ items, addItem, removeItem, updateQty, clear, subtotal, shipping, total, count, open, setOpen }}>
            {children}
        </CartCtx.Provider>
    );
}

export const useCart = () => useContext(CartCtx);
