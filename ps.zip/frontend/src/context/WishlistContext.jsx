import React, { createContext, useCallback, useContext, useEffect, useState } from "react";
import { api } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";

const WishlistCtx = createContext(null);
const GUEST_KEY = "pz_wishlist_v1";

export function WishlistProvider({ children }) {
    const { user } = useAuth();
    const [ids, setIds] = useState([]);        // Set of poster ids
    const [items, setItems] = useState([]);    // Full poster docs (only for logged-in users)
    const [loading, setLoading] = useState(false);

    // Load — from API when logged-in, from localStorage when guest
    const reload = useCallback(async () => {
        if (user) {
            setLoading(true);
            try {
                const { data } = await api.get("/wishlist");
                setItems(data);
                setIds(data.map((p) => p.id));
            } catch { /* ignore */ }
            finally { setLoading(false); }
        } else {
            try {
                const raw = localStorage.getItem(GUEST_KEY);
                const arr = raw ? JSON.parse(raw) : [];
                setIds(arr);
                setItems([]);
            } catch { setIds([]); }
        }
    }, [user]);

    useEffect(() => { reload(); }, [reload]);

    const persistGuest = (arr) => {
        localStorage.setItem(GUEST_KEY, JSON.stringify(arr));
    };

    const toggle = async (posterId) => {
        const has = ids.includes(posterId);
        if (user) {
            if (has) {
                setIds((prev) => prev.filter((x) => x !== posterId));
                setItems((prev) => prev.filter((p) => p.id !== posterId));
                try { await api.delete(`/wishlist/${posterId}`); } catch { reload(); }
            } else {
                setIds((prev) => [...prev, posterId]);
                try {
                    await api.post(`/wishlist/${posterId}`);
                    reload();
                } catch { reload(); }
            }
        } else {
            const next = has ? ids.filter((x) => x !== posterId) : [...ids, posterId];
            setIds(next);
            persistGuest(next);
        }
    };

    const has = (posterId) => ids.includes(posterId);

    // Merge guest → server on login
    useEffect(() => {
        if (!user) return;
        try {
            const raw = localStorage.getItem(GUEST_KEY);
            const guest = raw ? JSON.parse(raw) : [];
            if (guest.length === 0) return;
            Promise.all(guest.map((id) => api.post(`/wishlist/${id}`).catch(() => null)))
                .then(() => {
                    localStorage.removeItem(GUEST_KEY);
                    reload();
                });
        } catch { /* ignore */ }
        // eslint-disable-next-line
    }, [user]);

    return (
        <WishlistCtx.Provider value={{ ids, items, loading, toggle, has, reload, count: ids.length }}>
            {children}
        </WishlistCtx.Provider>
    );
}

export const useWishlist = () => useContext(WishlistCtx);
