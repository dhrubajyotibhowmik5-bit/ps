import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { formatPrice } from "@/lib/api";
import WishlistHeart from "@/components/WishlistHeart";

export default function PosterCard({ poster, tall = false, testId, className = "" }) {
    return (
        <motion.div
            variants={{
                hidden: { opacity: 0, y: 30 },
                show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.2, 0.7, 0.2, 1] } },
            }}
            className={className}
        >
            <Link
                data-testid={testId || `poster-card-${poster.slug}`}
                to={`/product/${poster.slug}`}
                className="poster-tile block group"
            >
                <div className={`tile-img-wrap bg-pz-surface ${tall ? "aspect-[2/3]" : "aspect-[4/5]"}`}>
                    <img
                        src={poster.image_url}
                        alt={poster.title}
                        className="w-full h-full object-cover"
                        loading="lazy"
                    />
                    {poster.featured && <div className="sale-tag">Featured</div>}
                    <div className="absolute top-3 right-3 z-10">
                        <WishlistHeart posterId={poster.id} size={16} />
                    </div>
                    <div className="tile-overlay">
                        <div className="tile-overlay-cta">
                            View poster <ArrowUpRight className="w-3 h-3 hover-arrow" />
                        </div>
                    </div>
                </div>
                <div className="p-4">
                    <div className="eyebrow">{poster.category}</div>
                    <div className="font-serif-display text-xl leading-tight mt-1 group-hover:text-[#FF3B30] transition-colors">
                        {poster.title}
                    </div>
                    <div className="mt-2 flex justify-between items-center">
                        <span className="font-medium text-sm tracking-tight">{formatPrice(poster.price)}</span>
                        <span className="text-xs text-pz-muted">From A4</span>
                    </div>
                </div>
            </Link>
        </motion.div>
    );
}
