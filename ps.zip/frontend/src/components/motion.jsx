import React from "react";
import { motion } from "framer-motion";

export const Reveal = ({ children, delay = 0, y = 30, className = "", once = true }) => (
    <motion.div
        initial={{ opacity: 0, y }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once, margin: "-60px" }}
        transition={{ duration: 0.8, ease: [0.2, 0.7, 0.2, 1], delay }}
        className={className}
    >
        {children}
    </motion.div>
);

// Splits text into words that fade+rise, staggered.
export const AnimatedHeading = ({ children, className = "", stagger = 0.05, delay = 0 }) => {
    const words = String(children).split(" ");
    return (
        <span className={className} aria-label={String(children)}>
            {words.map((w, i) => (
                <motion.span
                    aria-hidden="true"
                    key={i}
                    initial={{ opacity: 0, y: "60%" }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{
                        duration: 0.9,
                        ease: [0.2, 0.7, 0.2, 1],
                        delay: delay + i * stagger,
                    }}
                    style={{ display: "inline-block", marginRight: "0.28em", willChange: "transform,opacity" }}
                >
                    {w}
                </motion.span>
            ))}
        </span>
    );
};

// Container for staggered children (use with StaggerChild)
export const StaggerContainer = ({ children, delay = 0, stagger = 0.08, className = "", ...rest }) => (
    <motion.div
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, margin: "-80px" }}
        variants={{
            hidden: {},
            show: { transition: { staggerChildren: stagger, delayChildren: delay } },
        }}
        className={className}
        {...rest}
    >
        {children}
    </motion.div>
);

export const StaggerChild = ({ children, className = "", y = 24 }) => (
    <motion.div
        variants={{
            hidden: { opacity: 0, y },
            show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.2, 0.7, 0.2, 1] } },
        }}
        className={className}
    >
        {children}
    </motion.div>
);
