import React, { useRef, useState } from "react";
import { api } from "@/lib/api";
import { toast } from "sonner";
import { X, FileText, Loader2, CheckCircle2, AlertCircle, Download, Upload } from "lucide-react";

const SAMPLE_CSV = `title,category,price,image_url,description,featured,tags,stock
"Cosmic Dust","Abstract",349,"https://images.unsplash.com/photo-1706630909453-c1058a447373?auto=format&fit=crop&w=800","A deep-space swirl print",true,"space,color",100
"Neon Alley","Travel",289,"https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=800","Rain-soaked Tokyo lane",false,"tokyo,night",100
"Keep It Simple","Minimal",199,"https://images.unsplash.com/photo-1495001258031-d1b407bc1776?auto=format&fit=crop&w=800","Bold typographic minimalism",false,"typography",100
`;

function parseCsvPreview(text) {
    // Minimal CSV parser with quoted-field support (best-effort preview only)
    const lines = text.replace(/\r\n/g, "\n").split("\n").filter((l) => l.length > 0);
    if (lines.length === 0) return { headers: [], rows: [] };
    const splitCsv = (line) => {
        const out = [];
        let cur = "";
        let inQuote = false;
        for (let i = 0; i < line.length; i++) {
            const c = line[i];
            if (inQuote) {
                if (c === '"' && line[i + 1] === '"') { cur += '"'; i++; }
                else if (c === '"') { inQuote = false; }
                else { cur += c; }
            } else {
                if (c === '"') inQuote = true;
                else if (c === ",") { out.push(cur); cur = ""; }
                else cur += c;
            }
        }
        out.push(cur);
        return out.map((s) => s.trim());
    };
    const headers = splitCsv(lines[0]).map((h) => h.toLowerCase());
    const rows = lines.slice(1, 51).map((l) => {
        const cells = splitCsv(l);
        const obj = {};
        headers.forEach((h, i) => { obj[h] = cells[i] || ""; });
        return obj;
    });
    return { headers, rows };
}

export default function CsvImportModal({ open, onClose, onDone }) {
    const fileInputRef = useRef(null);
    const [csvText, setCsvText] = useState("");
    const [preview, setPreview] = useState({ headers: [], rows: [] });
    const [file, setFile] = useState(null);
    const [importing, setImporting] = useState(false);
    const [result, setResult] = useState(null);

    if (!open) return null;

    const REQUIRED = ["title", "category", "price", "image_url"];
    const missingCols = REQUIRED.filter((c) => !preview.headers.includes(c));

    const onFile = async (f) => {
        if (!f) return;
        if (!f.name.toLowerCase().endsWith(".csv")) {
            toast.error("Please choose a .csv file");
            return;
        }
        if (f.size > 2 * 1024 * 1024) {
            toast.error("CSV too large (max 2MB)");
            return;
        }
        const text = await f.text();
        setFile(f);
        setCsvText(text);
        setPreview(parseCsvPreview(text));
        setResult(null);
    };

    const downloadSample = () => {
        const blob = new Blob([SAMPLE_CSV], { type: "text/csv" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "poster-zone-sample.csv";
        a.click();
        URL.revokeObjectURL(url);
    };

    const doImport = async () => {
        if (!file) return;
        if (missingCols.length > 0) {
            toast.error(`Missing required columns: ${missingCols.join(", ")}`);
            return;
        }
        setImporting(true);
        try {
            const fd = new FormData();
            fd.append("file", file);
            const { data } = await api.post("/admin/posters/import-csv", fd, {
                headers: { "Content-Type": "multipart/form-data" },
            });
            setResult(data);
            if (data.count > 0) toast.success(`Imported ${data.count} posters`);
            if ((data.errors?.length || 0) + (data.skipped?.length || 0) > 0) {
                toast.warning(`${data.errors.length} errors · ${data.skipped.length} skipped`);
            }
            onDone?.();
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Import failed");
        } finally {
            setImporting(false);
        }
    };

    const reset = () => {
        setFile(null);
        setCsvText("");
        setPreview({ headers: [], rows: [] });
        setResult(null);
    };

    return (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" data-testid="csv-import-modal">
            <div className="bg-white w-full max-w-5xl max-h-[92vh] flex flex-col">
                <div className="p-6 border-b border-pz-border flex justify-between items-center">
                    <div>
                        <div className="eyebrow">Admin</div>
                        <h3 className="font-serif-display text-3xl">CSV Import</h3>
                    </div>
                    <button data-testid="csv-import-close" onClick={onClose} className="text-pz-muted hover:text-pz-ink"><X className="w-6 h-6" /></button>
                </div>

                {/* Toolbar */}
                <div className="p-6 border-b border-pz-border flex flex-wrap items-end gap-4">
                    <input
                        ref={fileInputRef}
                        data-testid="csv-import-input"
                        type="file"
                        accept=".csv,text/csv"
                        className="hidden"
                        onChange={(e) => { onFile(e.target.files?.[0]); e.target.value = ""; }}
                    />
                    <button
                        data-testid="csv-import-pick-file"
                        onClick={() => fileInputRef.current?.click()}
                        className="pz-btn"
                    >
                        <FileText className="w-4 h-4" /> {file ? "Change CSV" : "Choose CSV"}
                    </button>
                    <button
                        data-testid="csv-import-sample"
                        onClick={downloadSample}
                        className="pz-btn pz-btn-outline"
                    >
                        <Download className="w-4 h-4" /> Download sample CSV
                    </button>
                    {file && (
                        <div className="text-sm">
                            <div className="eyebrow">File</div>
                            <div className="font-medium" data-testid="csv-filename">{file.name}</div>
                        </div>
                    )}
                    <div className="ml-auto text-xs text-pz-muted max-w-md text-right">
                        Required columns: <b>title, category, price, image_url</b><br/>
                        Optional: description, slug, featured, tags, stock
                    </div>
                </div>

                {/* Preview / Result */}
                <div className="flex-1 overflow-y-auto p-6" data-testid="csv-import-body">
                    {!file && !result && (
                        <div className="text-center py-24 border-2 border-dashed border-pz-border">
                            <FileText className="w-10 h-10 mx-auto text-pz-muted" />
                            <div className="font-serif-display text-2xl italic mt-4">Choose a CSV to preview.</div>
                            <p className="text-pz-muted text-sm mt-2">Download the sample above to see the exact format.</p>
                        </div>
                    )}

                    {file && !result && (
                        <>
                            {missingCols.length > 0 && (
                                <div className="mb-4 p-3 border border-red-300 bg-red-50 text-sm flex items-center gap-2" data-testid="csv-missing-cols">
                                    <AlertCircle className="w-4 h-4 text-red-500" />
                                    Missing required columns: <b>{missingCols.join(", ")}</b>
                                </div>
                            )}
                            <div className="text-sm text-pz-muted mb-2">
                                Preview — first {Math.min(preview.rows.length, 50)} rows of {preview.rows.length}:
                            </div>
                            <div className="overflow-x-auto border border-pz-border">
                                <table className="w-full text-xs" data-testid="csv-preview-table">
                                    <thead className="bg-pz-surface">
                                        <tr>
                                            {preview.headers.map((h) => (
                                                <th key={h} className={`text-left px-3 py-2 eyebrow ${REQUIRED.includes(h) ? "text-pz-ink" : "text-pz-muted"}`}>
                                                    {h}{REQUIRED.includes(h) && <span className="text-[#FF3B30] ml-0.5">*</span>}
                                                </th>
                                            ))}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {preview.rows.map((r, i) => (
                                            <tr key={i} className="border-t border-pz-border" data-testid={`csv-preview-row-${i}`}>
                                                {preview.headers.map((h) => (
                                                    <td key={h} className="px-3 py-2 truncate max-w-[220px]">{r[h] || <span className="text-pz-muted italic">—</span>}</td>
                                                ))}
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </>
                    )}

                    {result && (
                        <div className="space-y-4" data-testid="csv-import-result">
                            <div className="grid grid-cols-3 gap-4">
                                <ResultCard icon={<CheckCircle2 className="w-5 h-5 text-emerald-600" />} label="Created" value={result.count} testId="csv-result-created" />
                                <ResultCard icon={<AlertCircle className="w-5 h-5 text-amber-500" />} label="Skipped" value={result.skipped?.length || 0} testId="csv-result-skipped" />
                                <ResultCard icon={<AlertCircle className="w-5 h-5 text-red-500" />} label="Errors" value={result.errors?.length || 0} testId="csv-result-errors" />
                            </div>
                            {result.created?.length > 0 && (
                                <details className="border border-pz-border p-4" open>
                                    <summary className="cursor-pointer text-sm font-medium">Created ({result.count})</summary>
                                    <ul className="mt-2 text-xs space-y-1 max-h-40 overflow-y-auto">
                                        {result.created.map((c, i) => <li key={i} data-testid={`csv-created-${i}`}>Row {c.row}: {c.title} <span className="text-pz-muted">({c.slug})</span></li>)}
                                    </ul>
                                </details>
                            )}
                            {result.skipped?.length > 0 && (
                                <details className="border border-pz-border p-4">
                                    <summary className="cursor-pointer text-sm font-medium">Skipped ({result.skipped.length})</summary>
                                    <ul className="mt-2 text-xs space-y-1 max-h-40 overflow-y-auto">
                                        {result.skipped.map((s, i) => <li key={i}>Row {s.row}: {s.title} — <span className="text-pz-muted">{s.reason}</span></li>)}
                                    </ul>
                                </details>
                            )}
                            {result.errors?.length > 0 && (
                                <details className="border border-red-200 p-4">
                                    <summary className="cursor-pointer text-sm font-medium text-red-700">Errors ({result.errors.length})</summary>
                                    <ul className="mt-2 text-xs space-y-1 max-h-40 overflow-y-auto">
                                        {result.errors.map((e, i) => <li key={i} className="text-red-700">Row {e.row}: {e.error}</li>)}
                                    </ul>
                                </details>
                            )}
                        </div>
                    )}
                </div>

                {/* Footer */}
                <div className="p-6 border-t border-pz-border flex justify-between items-center gap-3">
                    <div className="text-sm text-pz-muted">
                        {file && !result && `${preview.rows.length} rows in file`}
                        {result && `Done — ${result.count} posters imported`}
                    </div>
                    <div className="flex gap-3">
                        {result ? (
                            <>
                                <button onClick={reset} className="pz-btn pz-btn-outline">Import another</button>
                                <button data-testid="csv-import-done" onClick={onClose} className="pz-btn">Close</button>
                            </>
                        ) : (
                            <>
                                <button onClick={onClose} className="pz-btn pz-btn-outline">Cancel</button>
                                <button
                                    data-testid="csv-import-run"
                                    onClick={doImport}
                                    disabled={!file || importing || missingCols.length > 0 || preview.rows.length === 0}
                                    className="pz-btn"
                                >
                                    {importing
                                        ? <><Loader2 className="w-4 h-4 animate-spin" /> Importing…</>
                                        : <><Upload className="w-4 h-4" /> Import {preview.rows.length} row{preview.rows.length === 1 ? "" : "s"}</>}
                                </button>
                            </>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}

function ResultCard({ icon, label, value, testId }) {
    return (
        <div className="border border-pz-border p-4" data-testid={testId}>
            <div className="flex items-center gap-2">{icon}<div className="eyebrow">{label}</div></div>
            <div className="font-serif-display text-4xl tracking-tighter mt-2">{value}</div>
        </div>
    );
}
