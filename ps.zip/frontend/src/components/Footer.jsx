import React from "react";
import { Link } from "react-router-dom";
import { Instagram, Twitter, Youtube, Mail } from "lucide-react";

export default function Footer() {
    return (
        <footer className="mt-24 bg-pz-ink text-white">
            <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-20 grid gap-12 md:grid-cols-4">
                <div className="md:col-span-2">
                    <div className="font-serif-display text-4xl tracking-tighter">Poster<span className="text-[#FF3B30]">.</span>Zone</div>
                    <p className="mt-4 text-white/60 max-w-md leading-relaxed">
                        Curated wall art for the modern space. Museum-grade prints, obsessively packed and shipped worldwide.
                    </p>
                    <form className="mt-6 flex max-w-md border-b border-white/20 pb-2" onSubmit={(e) => e.preventDefault()}>
                        <input data-testid="footer-newsletter" type="email" placeholder="your@email.com" className="flex-1 bg-transparent outline-none placeholder:text-white/40 text-sm" />
                        <button data-testid="footer-newsletter-submit" className="text-xs tracking-widest uppercase hover:text-[#FF3B30] transition">Subscribe</button>
                    </form>
                </div>
                <div>
                    <div className="eyebrow text-white/50 mb-4">Shop</div>
                    <ul className="space-y-2 text-sm">
                        <li><Link to="/shop?category=Movies" className="hover:text-[#FF3B30]">Movies</Link></li>
                        <li><Link to="/shop?category=Anime" className="hover:text-[#FF3B30]">Anime</Link></li>
                        <li><Link to="/shop?category=Music" className="hover:text-[#FF3B30]">Music</Link></li>
                        <li><Link to="/shop?category=Motivational" className="hover:text-[#FF3B30]">Motivational</Link></li>
                        <li><Link to="/shop?category=Abstract" className="hover:text-[#FF3B30]">Abstract</Link></li>
                    </ul>
                </div>
                <div>
                    <div className="eyebrow text-white/50 mb-4">Company</div>
                    <ul className="space-y-2 text-sm">
                        <li><Link to="/about" className="hover:text-[#FF3B30]">About</Link></li>
                        <li><Link to="/contact" className="hover:text-[#FF3B30]">Contact</Link></li>
                        <li><Link to="/shop" className="hover:text-[#FF3B30]">All Prints</Link></li>
                    </ul>
                    <div className="flex gap-4 mt-6">
                        <a href="#" className="hover:text-[#FF3B30]"><Instagram className="w-4 h-4" /></a>
                        <a href="#" className="hover:text-[#FF3B30]"><Twitter className="w-4 h-4" /></a>
                        <a href="#" className="hover:text-[#FF3B30]"><Youtube className="w-4 h-4" /></a>
                        <a href="mailto:hello@posterzone.in" className="hover:text-[#FF3B30]"><Mail className="w-4 h-4" /></a>
                    </div>
                </div>
            </div>
            <div className="border-t border-white/10">
                <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-6 flex flex-col md:flex-row justify-between text-xs text-white/40 gap-2">
                    <div>© {new Date().getFullYear()} Poster Zone. All rights reserved.</div>
                    <div>Printed. Shipped. From India, worldwide.</div>
                </div>
            </div>
        </footer>
    );
}
