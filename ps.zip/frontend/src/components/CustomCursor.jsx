import React, { useEffect, useRef, useState } from "react";

/**
 * Trailing dot + expanding ring cursor.
 * On links/buttons the ring expands and turns accent color.
 * Hidden on touch devices via CSS media query.
 */
export default function CustomCursor() {
    const dotRef = useRef(null);
    const ringRef = useRef(null);
    const targetRef = useRef({ x: 0, y: 0 });
    const ringPosRef = useRef({ x: 0, y: 0 });
    const rafRef = useRef(null);
    const [hovering, setHovering] = useState(false);
    const [visible, setVisible] = useState(false);

    useEffect(() => {
        const move = (e) => {
            targetRef.current = { x: e.clientX, y: e.clientY };
            if (!visible) setVisible(true);
        };
        const leave = () => setVisible(false);
        const enter = () => setVisible(true);
        window.addEventListener("mousemove", move);
        document.addEventListener("mouseleave", leave);
        document.addEventListener("mouseenter", enter);

        const isInteractive = (el) => {
            if (!el || !(el instanceof HTMLElement)) return false;
            return !!el.closest("a, button, [role='button'], input[type='checkbox'], input[type='radio'], label, select, .poster-tile");
        };
        const onOver = (e) => { if (isInteractive(e.target)) setHovering(true); };
        const onOut = (e) => { if (isInteractive(e.target)) setHovering(false); };
        document.addEventListener("mouseover", onOver);
        document.addEventListener("mouseout", onOut);

        const tick = () => {
            // dot: snap to pointer
            if (dotRef.current) {
                dotRef.current.style.transform = `translate3d(${targetRef.current.x}px, ${targetRef.current.y}px, 0) translate(-50%, -50%)`;
            }
            // ring: lerp
            const p = ringPosRef.current;
            p.x += (targetRef.current.x - p.x) * 0.18;
            p.y += (targetRef.current.y - p.y) * 0.18;
            if (ringRef.current) {
                ringRef.current.style.transform = `translate3d(${p.x}px, ${p.y}px, 0) translate(-50%, -50%)`;
            }
            rafRef.current = requestAnimationFrame(tick);
        };
        rafRef.current = requestAnimationFrame(tick);
        return () => {
            window.removeEventListener("mousemove", move);
            document.removeEventListener("mouseleave", leave);
            document.removeEventListener("mouseenter", enter);
            document.removeEventListener("mouseover", onOver);
            document.removeEventListener("mouseout", onOut);
            if (rafRef.current) cancelAnimationFrame(rafRef.current);
        };
    }, [visible]);

    return (
        <>
            <div ref={dotRef} className={`pz-cursor-dot ${!visible ? "hidden" : ""}`} aria-hidden="true" />
            <div ref={ringRef} className={`pz-cursor-ring ${hovering ? "hover" : ""} ${!visible ? "hidden" : ""}`} aria-hidden="true" />
        </>
    );
}
