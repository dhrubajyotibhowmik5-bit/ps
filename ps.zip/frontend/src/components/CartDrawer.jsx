import React from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { useCart } from "@/context/CartContext";
import { Minus, Plus, X, ArrowRight } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { formatPrice } from "@/lib/api";

export default function CartDrawer() {
    const { open, setOpen, items, updateQty, removeItem, subtotal, shipping, total, count } = useCart();
    const nav = useNavigate();

    const goCheckout = () => {
        setOpen(false);
        nav("/checkout");
    };

    return (
        <Sheet open={open} onOpenChange={setOpen}>
            <SheetContent side="right" className="w-full sm:max-w-md p-0 bg-white flex flex-col">
                <SheetHeader className="p-6 border-b border-pz-border">
                    <SheetTitle className="font-serif-display text-3xl tracking-tighter text-left">
                        Your Cart {count > 0 && <span className="text-pz-muted text-lg">({count})</span>}
                    </SheetTitle>
                </SheetHeader>

                <div className="flex-1 overflow-y-auto p-6 space-y-6" data-testid="cart-items-list">
                    {items.length === 0 && (
                        <div className="text-center pt-16">
                            <div className="font-serif-display text-2xl italic">Your cart is empty.</div>
                            <p className="text-sm text-pz-muted mt-2">Every wall needs a soul.</p>
                            <Link data-testid="cart-empty-shop-cta" to="/shop" onClick={() => setOpen(false)} className="pz-btn mt-6 inline-flex">
                                Browse Shop <ArrowRight className="w-4 h-4 hover-arrow" />
                            </Link>
                        </div>
                    )}

                    {items.map((item) => (
                        <div key={`${item.poster_id}-${item.size}-${item.frame}`} className="flex gap-4" data-testid={`cart-item-${item.poster_id}`}>
                            <div className="w-24 h-32 bg-pz-surface overflow-hidden shrink-0">
                                <img src={item.image_url} alt={item.title} className="w-full h-full object-cover" />
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="flex justify-between gap-2">
                                    <div className="min-w-0">
                                        <div className="font-serif-display text-lg leading-tight truncate">{item.title}</div>
                                        <div className="text-xs text-pz-muted mt-1">{item.size}</div>
                                    </div>
                                    <button data-testid={`cart-remove-${item.poster_id}`} onClick={() => removeItem(item.poster_id, item.size, item.frame)} className="text-pz-muted hover:text-[#FF3B30]">
                                        <X className="w-4 h-4" />
                                    </button>
                                </div>
                                <div className="flex justify-between items-end mt-4">
                                    <div className="flex items-center gap-2 border border-pz-border">
                                        <button data-testid={`cart-qty-dec-${item.poster_id}`} onClick={() => updateQty(item.poster_id, item.size, item.frame, item.quantity - 1)} className="px-2 py-1 hover:bg-pz-surface">
                                            <Minus className="w-3 h-3" />
                                        </button>
                                        <span className="text-sm w-6 text-center" data-testid={`cart-qty-${item.poster_id}`}>{item.quantity}</span>
                                        <button data-testid={`cart-qty-inc-${item.poster_id}`} onClick={() => updateQty(item.poster_id, item.size, item.frame, item.quantity + 1)} className="px-2 py-1 hover:bg-pz-surface">
                                            <Plus className="w-3 h-3" />
                                        </button>
                                    </div>
                                    <div className="font-medium tracking-tight" data-testid={`cart-line-total-${item.poster_id}`}>
                                        {formatPrice(item.unit_price * item.quantity)}
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {items.length > 0 && (
                    <div className="border-t border-pz-border p-6 space-y-4 bg-white">
                        <div className="flex justify-between text-sm">
                            <span className="text-pz-muted">Subtotal</span>
                            <span data-testid="cart-subtotal">{formatPrice(subtotal)}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                            <span className="text-pz-muted">Shipping</span>
                            <span data-testid="cart-shipping">{shipping === 0 ? "Free" : formatPrice(shipping)}</span>
                        </div>
                        <div className="flex justify-between text-lg font-medium pt-2 border-t border-pz-border">
                            <span>Total</span>
                            <span data-testid="cart-total">{formatPrice(total)}</span>
                        </div>
                        <button data-testid="cart-checkout-btn" onClick={goCheckout} className="pz-btn w-full">
                            Checkout <ArrowRight className="w-4 h-4 hover-arrow" />
                        </button>
                        {subtotal < 999 && (
                            <p className="text-xs text-pz-muted text-center">Add {formatPrice(999 - subtotal)} more for free shipping.</p>
                        )}
                    </div>
                )}
            </SheetContent>
        </Sheet>
    );
}
