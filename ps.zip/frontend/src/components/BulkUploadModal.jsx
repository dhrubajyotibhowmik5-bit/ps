import React, { useRef, useState } from "react";
import { api, formatPrice, API } from "@/lib/api";
import { toast } from "sonner";
import { Upload, X, Trash2, Loader2, CheckCircle2, AlertCircle } from "lucide-react";

const CATEGORIES = ["Movies", "Anime", "Music", "Motivational", "Sports", "Abstract", "Nature", "Minimal", "Travel", "Gaming"];

const slugify = (s) =>
    s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60) || `poster-${Date.now()}`;

const titleFromFilename = (name) => {
    const base = name.replace(/\.[^.]+$/, "").replace(/[-_]+/g, " ");
    return base.replace(/\b\w/g, (c) => c.toUpperCase()).slice(0, 60) || "Untitled";
};

const abs = (u) => (u?.startsWith("http") ? u : `${API.replace(/\/api$/, "")}${u}`);

const DEFAULT_SIZES = [
    { label: "A4 (8x11 in)", price_delta: 0 },
    { label: "A3 (12x17 in)", price_delta: 200 },
    { label: "A2 (17x23 in)", price_delta: 500 },
];
const DEFAULT_FRAMES = [];

export default function BulkUploadModal({ open, onClose, onDone }) {
    const fileInputRef = useRef(null);
    const [rows, setRows] = useState([]); // {file, uploading, url, error, title, slug, category, price, description}
    const [defaultCategory, setDefaultCategory] = useState("Movies");
    const [defaultPrice, setDefaultPrice] = useState(299);
    const [saving, setSaving] = useState(false);

    if (!open) return null;

    const addFiles = async (files) => {
        const arr = Array.from(files).slice(0, 30);
        if (arr.length === 0) return;
        const newRows = arr.map((file) => ({
            file,
            uploading: true,
            url: "",
            error: "",
            title: titleFromFilename(file.name),
            slug: slugify(titleFromFilename(file.name)) + "-" + Math.random().toString(36).slice(2, 6),
            category: defaultCategory,
            price: defaultPrice,
            description: `Curated ${defaultCategory.toLowerCase()} print by Poster Zone. Museum-grade paper, ships worldwide.`,
        }));
        setRows((prev) => [...prev, ...newRows]);

        // Upload in parallel via bulk endpoint
        const fd = new FormData();
        arr.forEach((f) => fd.append("files", f));
        try {
            const { data } = await api.post("/admin/upload/bulk", fd, {
                headers: { "Content-Type": "multipart/form-data" },
            });
            const startIdx = rows.length;
            setRows((prev) => {
                const next = [...prev];
                data.results.forEach((r, i) => {
                    const target = next[startIdx + i];
                    if (!target) return;
                    target.uploading = false;
                    if (r.error) target.error = r.error;
                    else target.url = abs(r.url);
                });
                return next;
            });
            const failed = data.results.filter((r) => r.error).length;
            if (failed > 0) toast.warning(`${data.results.length - failed} uploaded · ${failed} failed`);
            else toast.success(`Uploaded ${data.results.length} images`);
        } catch (err) {
            toast.error("Bulk upload failed");
            setRows((prev) => prev.map((r) => (r.uploading ? { ...r, uploading: false, error: "Upload failed" } : r)));
        }
    };

    const updateRow = (idx, patch) => {
        setRows((prev) => prev.map((r, i) => (i === idx ? { ...r, ...patch } : r)));
    };

    const removeRow = (idx) => setRows((prev) => prev.filter((_, i) => i !== idx));

    const applyDefaults = () => {
        setRows((prev) =>
            prev.map((r) => ({
                ...r,
                category: defaultCategory,
                price: defaultPrice,
                description: `Curated ${defaultCategory.toLowerCase()} print by Poster Zone. Museum-grade paper, ships worldwide.`,
            }))
        );
        toast.success("Defaults applied to all rows");
    };

    const saveAll = async () => {
        const ready = rows.filter((r) => r.url && !r.error);
        if (ready.length === 0) {
            toast.error("No posters ready to save");
            return;
        }
        // Validate
        for (const r of ready) {
            if (!r.title.trim() || !r.slug.trim() || !r.category || !r.price) {
                toast.error(`Row "${r.title}" is missing required fields`);
                return;
            }
        }
        setSaving(true);
        try {
            const payload = ready.map((r) => ({
                slug: slugify(r.slug),
                title: r.title,
                description: r.description || `Poster print by Poster Zone.`,
                price: Number(r.price),
                category: r.category,
                tags: [],
                image_url: r.url,
                sizes: DEFAULT_SIZES,
                frame_options: DEFAULT_FRAMES,
                stock: 100,
                featured: false,
            }));
            const { data } = await api.post("/admin/posters/bulk", payload);
            toast.success(`${data.count} posters created`);
            if (data.errors?.length) {
                toast.warning(`${data.errors.length} failed (see console)`);
                console.warn("Bulk create errors:", data.errors);
            }
            setRows([]);
            onDone?.();
            onClose();
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Save failed");
        } finally {
            setSaving(false);
        }
    };

    const readyCount = rows.filter((r) => r.url && !r.error).length;
    const uploadingCount = rows.filter((r) => r.uploading).length;

    return (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" data-testid="bulk-upload-modal">
            <div className="bg-white w-full max-w-6xl max-h-[92vh] flex flex-col">
                <div className="p-6 border-b border-pz-border flex justify-between items-center">
                    <div>
                        <div className="eyebrow">Admin</div>
                        <h3 className="font-serif-display text-3xl">Bulk Upload Posters</h3>
                    </div>
                    <button data-testid="bulk-upload-close" onClick={onClose} className="text-pz-muted hover:text-pz-ink text-2xl">
                        <X className="w-6 h-6" />
                    </button>
                </div>

                {/* Toolbar */}
                <div className="p-6 border-b border-pz-border flex flex-wrap items-end gap-4">
                    <input
                        ref={fileInputRef}
                        data-testid="bulk-upload-input"
                        type="file"
                        multiple
                        accept="image/png,image/jpeg,image/webp,image/gif"
                        className="hidden"
                        onChange={(e) => { addFiles(e.target.files); e.target.value = ""; }}
                    />
                    <button
                        data-testid="bulk-upload-pick-files"
                        onClick={() => fileInputRef.current?.click()}
                        className="pz-btn"
                    >
                        <Upload className="w-4 h-4" /> Choose files
                    </button>
                    <div>
                        <div className="eyebrow mb-1">Default category</div>
                        <select
                            data-testid="bulk-default-category"
                            value={defaultCategory}
                            onChange={(e) => setDefaultCategory(e.target.value)}
                            className="border border-pz-border p-2 text-sm bg-transparent"
                        >
                            {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                        </select>
                    </div>
                    <div>
                        <div className="eyebrow mb-1">Default price (₹)</div>
                        <input
                            data-testid="bulk-default-price"
                            type="number"
                            value={defaultPrice}
                            onChange={(e) => setDefaultPrice(Number(e.target.value) || 0)}
                            className="border border-pz-border p-2 text-sm w-24"
                        />
                    </div>
                    <button
                        data-testid="bulk-apply-defaults"
                        onClick={applyDefaults}
                        disabled={rows.length === 0}
                        className="pz-btn pz-btn-outline"
                    >
                        Apply to all
                    </button>
                    <div className="ml-auto text-sm text-pz-muted">
                        {rows.length > 0 && <span data-testid="bulk-status">
                            {uploadingCount > 0 && <span className="mr-3"><Loader2 className="inline w-3 h-3 animate-spin" /> {uploadingCount} uploading</span>}
                            <span className="text-emerald-700">{readyCount} ready</span>
                        </span>}
                    </div>
                </div>

                {/* Rows */}
                <div className="flex-1 overflow-y-auto p-6" data-testid="bulk-rows">
                    {rows.length === 0 ? (
                        <div className="text-center py-24 border-2 border-dashed border-pz-border">
                            <Upload className="w-10 h-10 mx-auto text-pz-muted" />
                            <div className="font-serif-display text-2xl italic mt-4">Choose files to begin.</div>
                            <p className="text-pz-muted text-sm mt-2">Up to 30 images per batch · Max 8MB each · JPG/PNG/WebP/GIF</p>
                        </div>
                    ) : (
                        <div className="space-y-3">
                            {rows.map((r, idx) => (
                                <div key={idx} data-testid={`bulk-row-${idx}`} className="grid grid-cols-12 gap-3 items-center border border-pz-border p-3">
                                    <div className="col-span-1">
                                        <div className="w-16 h-20 bg-pz-surface overflow-hidden relative">
                                            {r.url && <img src={r.url} alt="" className="w-full h-full object-cover" />}
                                            {r.uploading && <div className="absolute inset-0 flex items-center justify-center bg-black/40"><Loader2 className="w-5 h-5 animate-spin text-white" /></div>}
                                            {r.error && <div className="absolute inset-0 flex items-center justify-center bg-red-500/70"><AlertCircle className="w-5 h-5 text-white" /></div>}
                                            {r.url && !r.uploading && !r.error && <div className="absolute top-1 right-1"><CheckCircle2 className="w-4 h-4 text-emerald-500 bg-white rounded-full" /></div>}
                                        </div>
                                    </div>
                                    <div className="col-span-4">
                                        <input
                                            data-testid={`bulk-title-${idx}`}
                                            placeholder="Title"
                                            value={r.title}
                                            onChange={(e) => updateRow(idx, { title: e.target.value, slug: slugify(e.target.value) })}
                                            className="w-full border border-pz-border p-2 text-sm mb-1"
                                        />
                                        <input
                                            data-testid={`bulk-slug-${idx}`}
                                            placeholder="slug-url"
                                            value={r.slug}
                                            onChange={(e) => updateRow(idx, { slug: e.target.value })}
                                            className="w-full border border-pz-border p-1 text-xs text-pz-muted"
                                        />
                                    </div>
                                    <div className="col-span-2">
                                        <select
                                            data-testid={`bulk-category-${idx}`}
                                            value={r.category}
                                            onChange={(e) => updateRow(idx, { category: e.target.value })}
                                            className="w-full border border-pz-border p-2 text-sm bg-transparent"
                                        >
                                            {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                                        </select>
                                    </div>
                                    <div className="col-span-2">
                                        <input
                                            data-testid={`bulk-price-${idx}`}
                                            type="number"
                                            value={r.price}
                                            onChange={(e) => updateRow(idx, { price: Number(e.target.value) || 0 })}
                                            className="w-full border border-pz-border p-2 text-sm"
                                        />
                                    </div>
                                    <div className="col-span-2 text-xs">
                                        {r.uploading && <span className="text-pz-muted">Uploading…</span>}
                                        {r.error && <span className="text-red-500" title={r.error}>{r.error}</span>}
                                        {r.url && !r.error && <span className="text-emerald-700">Ready · {formatPrice(r.price)}</span>}
                                    </div>
                                    <div className="col-span-1 text-right">
                                        <button
                                            data-testid={`bulk-remove-${idx}`}
                                            onClick={() => removeRow(idx)}
                                            className="text-pz-muted hover:text-red-500"
                                            title="Remove row"
                                        >
                                            <Trash2 className="w-4 h-4" />
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* Footer actions */}
                <div className="p-6 border-t border-pz-border flex justify-between items-center gap-3">
                    <div className="text-sm text-pz-muted">
                        {rows.length > 0 && `${rows.length} rows · ${readyCount} ready to save`}
                    </div>
                    <div className="flex gap-3">
                        <button onClick={onClose} className="pz-btn pz-btn-outline">Cancel</button>
                        <button
                            data-testid="bulk-save-all"
                            onClick={saveAll}
                            disabled={saving || readyCount === 0 || uploadingCount > 0}
                            className="pz-btn"
                        >
                            {saving ? <><Loader2 className="w-4 h-4 animate-spin" /> Saving…</> : `Save ${readyCount} poster${readyCount === 1 ? "" : "s"}`}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
