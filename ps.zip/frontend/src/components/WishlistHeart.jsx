import React from "react";
import { Heart } from "lucide-react";
import { useWishlist } from "@/context/WishlistContext";

export default function WishlistHeart({ posterId, className = "", size = 20 }) {
    const { has, toggle } = useWishlist();
    const active = has(posterId);
    return (
        <button
            data-testid={`wishlist-heart-${posterId}`}
            aria-label={active ? "Remove from wishlist" : "Save to wishlist"}
            aria-pressed={active}
            onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                toggle(posterId);
            }}
            className={`inline-flex items-center justify-center bg-white/95 hover:bg-white shadow-sm border border-pz-border transition ${className}`}
            style={{ width: size + 16, height: size + 16 }}
        >
            <Heart
                width={size}
                height={size}
                strokeWidth={active ? 0 : 1.5}
                className={active ? "text-[#FF3B30]" : "text-pz-ink hover:text-[#FF3B30] transition-colors"}
                fill={active ? "#FF3B30" : "transparent"}
            />
        </button>
    );
}
