import React, { useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { ShoppingBag, User, Search, Menu, X, LogOut, Shield, Heart, ArrowUpRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import { useWishlist } from "@/context/WishlistContext";

export default function Nav() {
    const { count, setOpen } = useCart();
    const { user, logout } = useAuth();
    const { count: wishCount } = useWishlist();
    const [mobileOpen, setMobileOpen] = useState(false);
    const [q, setQ] = useState("");
    const [profileOpen, setProfileOpen] = useState(false);
    const nav = useNavigate();

    const submitSearch = (e) => {
        e.preventDefault();
        if (q.trim()) nav(`/shop?q=${encodeURIComponent(q.trim())}`);
    };

    const NavLinks = ({ onClick }) => (
        <>
            <NavLink data-testid="nav-shop" to="/shop" onClick={onClick} className={({ isActive }) => `text-sm tracking-widest uppercase ${isActive ? 'text-[#FF3B30]' : 'text-pz-ink hover:text-[#FF3B30]'} transition-colors`}>Shop</NavLink>
            <NavLink data-testid="nav-movies" to="/shop?category=Movies" onClick={onClick} className="text-sm tracking-widest uppercase text-pz-ink hover:text-[#FF3B30]">Movies</NavLink>
            <NavLink data-testid="nav-anime" to="/shop?category=Anime" onClick={onClick} className="text-sm tracking-widest uppercase text-pz-ink hover:text-[#FF3B30]">Anime</NavLink>
            <NavLink data-testid="nav-minimal" to="/shop?category=Minimal" onClick={onClick} className="text-sm tracking-widest uppercase text-pz-ink hover:text-[#FF3B30]">Minimal</NavLink>
            <NavLink data-testid="nav-abstract" to="/shop?category=Abstract" onClick={onClick} className="text-sm tracking-widest uppercase text-pz-ink hover:text-[#FF3B30]">Abstract</NavLink>
            <NavLink data-testid="nav-about" to="/about" onClick={onClick} className="text-sm tracking-widest uppercase text-pz-ink hover:text-[#FF3B30]">About</NavLink>
        </>
    );

    return (
        <>
        <header className="sticky top-0 z-40 backdrop-blur-xl bg-white/75 border-b border-black/5">
            <div className="max-w-[1400px] mx-auto px-6 lg:px-10 h-20 flex items-center justify-between gap-8">
                <button data-testid="mobile-nav-toggle" className="lg:hidden" onClick={() => setMobileOpen(true)} aria-label="Menu">
                    <Menu className="w-5 h-5" />
                </button>

                <Link data-testid="brand-logo" to="/" className="font-serif-display text-3xl tracking-tighter leading-none">
                    Poster<span className="text-[#FF3B30]">.</span>Zone
                </Link>

                <nav className="hidden lg:flex items-center gap-8">
                    <NavLinks />
                </nav>

                <div className="flex items-center gap-3">
                    <form onSubmit={submitSearch} className="hidden md:flex items-center gap-2 border-b border-black/10 pb-1">
                        <Search className="w-4 h-4 text-pz-muted" />
                        <input
                            data-testid="nav-search-input"
                            value={q}
                            onChange={(e) => setQ(e.target.value)}
                            placeholder="Search posters"
                            className="bg-transparent outline-none text-sm w-40 placeholder:text-pz-muted"
                        />
                    </form>

                    <div className="relative">
                        <button
                            data-testid="nav-profile-btn"
                            onClick={() => setProfileOpen((v) => !v)}
                            className="p-2 hover:bg-pz-surface rounded-sm transition"
                            aria-label="Account"
                        >
                            <User className="w-5 h-5" />
                        </button>
                        {profileOpen && (
                            <div className="absolute right-0 top-full mt-2 w-56 bg-white border border-pz-border shadow-lg py-2 z-50" onMouseLeave={() => setProfileOpen(false)}>
                                {user ? (
                                    <>
                                        <div className="px-4 py-2 border-b border-pz-border">
                                            <div className="text-sm font-medium truncate">{user.name}</div>
                                            <div className="text-xs text-pz-muted truncate">{user.email}</div>
                                        </div>
                                        <Link data-testid="nav-account-link" to="/account" onClick={() => setProfileOpen(false)} className="block px-4 py-2 text-sm hover:bg-pz-surface">My Orders</Link>
                                        {user.role === "admin" && (
                                            <Link data-testid="nav-admin-link" to="/admin" onClick={() => setProfileOpen(false)} className="flex items-center gap-2 px-4 py-2 text-sm hover:bg-pz-surface">
                                                <Shield className="w-4 h-4" /> Admin
                                            </Link>
                                        )}
                                        <button data-testid="nav-logout-btn" onClick={() => { logout(); setProfileOpen(false); }} className="w-full flex items-center gap-2 px-4 py-2 text-sm text-left hover:bg-pz-surface">
                                            <LogOut className="w-4 h-4" /> Logout
                                        </button>
                                    </>
                                ) : (
                                    <>
                                        <Link data-testid="nav-login-link" to="/login" onClick={() => setProfileOpen(false)} className="block px-4 py-2 text-sm hover:bg-pz-surface">Login</Link>
                                        <Link data-testid="nav-signup-link" to="/signup" onClick={() => setProfileOpen(false)} className="block px-4 py-2 text-sm hover:bg-pz-surface">Create Account</Link>
                                    </>
                                )}
                            </div>
                        )}
                    </div>

                    <Link
                        data-testid="nav-wishlist-btn"
                        to="/wishlist"
                        className="relative p-2 hover:bg-pz-surface rounded-sm transition"
                        aria-label="Wishlist"
                    >
                        <Heart className="w-5 h-5" />
                        {wishCount > 0 && (
                            <span data-testid="nav-wishlist-count" className="absolute -top-0 -right-0 bg-[#FF3B30] text-white text-[10px] w-4 h-4 flex items-center justify-center rounded-full font-medium">
                                {wishCount}
                            </span>
                        )}
                    </Link>

                    <button
                        data-testid="nav-cart-btn"
                        onClick={() => setOpen(true)}
                        className="relative p-2 hover:bg-pz-surface rounded-sm transition"
                        aria-label="Cart"
                    >
                        <ShoppingBag className="w-5 h-5" />
                        {count > 0 && (
                            <span data-testid="nav-cart-count" className="absolute -top-0 -right-0 bg-[#FF3B30] text-white text-[10px] w-4 h-4 flex items-center justify-center rounded-full font-medium">
                                {count}
                            </span>
                        )}
                    </button>
                </div>
            </div>

            {/* Mobile drawer — rendered as sibling of <header> (moved out because `backdrop-filter` on the header traps `position:fixed` children to the header's box, causing overlap with the page content) */}
        </header>
        <AnimatePresence>
            {mobileOpen && (
                <motion.div
                    key="mobile-drawer"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.35, ease: [0.2, 0.7, 0.2, 1] }}
                    className="fixed inset-0 z-[100] lg:hidden overflow-hidden"
                    data-testid="mobile-nav-drawer"
                >
                    {/* Frosted glass backdrop */}
                    <div className="absolute inset-0 bg-white/70 backdrop-blur-2xl" />
                    {/* Soft ambient glows */}
                    <div className="absolute -top-32 -right-24 w-[380px] h-[380px] rounded-full bg-[#FF3B30] opacity-[0.08] blur-3xl pointer-events-none" />
                    <div className="absolute -bottom-40 -left-20 w-[420px] h-[420px] rounded-full bg-black opacity-[0.05] blur-3xl pointer-events-none" />

                    {/* Red accent line that draws in from top */}
                    <motion.div
                        initial={{ scaleY: 0 }}
                        animate={{ scaleY: 1 }}
                        exit={{ scaleY: 0 }}
                        transition={{ duration: 0.6, ease: [0.2, 0.7, 0.2, 1], delay: 0.15 }}
                        className="absolute top-0 left-0 h-full w-[3px] bg-[#FF3B30] origin-top"
                    />

                    <motion.div
                        initial={{ x: -20, opacity: 0 }}
                        animate={{ x: 0, opacity: 1 }}
                        exit={{ x: -20, opacity: 0 }}
                        transition={{ duration: 0.5, ease: [0.2, 0.7, 0.2, 1] }}
                        className="relative h-full flex flex-col overflow-y-auto"
                    >
                        {/* Top row */}
                        <div className="p-6 flex justify-between items-center border-b border-black/5">
                            <Link data-testid="mobile-brand" to="/" className="font-serif-display text-2xl" onClick={() => setMobileOpen(false)}>
                                Poster<span className="text-[#FF3B30]">.</span>Zone
                            </Link>
                            <button
                                data-testid="mobile-close"
                                onClick={() => setMobileOpen(false)}
                                aria-label="Close menu"
                                className="w-10 h-10 flex items-center justify-center rounded-full border border-black/10 hover:bg-black hover:text-white transition-colors"
                            >
                                <X className="w-5 h-5" />
                            </button>
                        </div>

                        {/* Eyebrow */}
                        <motion.div
                            initial={{ opacity: 0, y: 12 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.5, delay: 0.25 }}
                            className="px-6 pt-8 eyebrow"
                        >
                            Explore the collection
                        </motion.div>

                        {/* Link list — big editorial */}
                        <nav className="px-6 py-6 flex flex-col">
                            {[
                                { to: "/shop", label: "Shop all", testId: "mobile-nav-shop" },
                                { to: "/shop?category=Movies", label: "Movies", testId: "mobile-nav-movies" },
                                { to: "/shop?category=Anime", label: "Anime", testId: "mobile-nav-anime" },
                                { to: "/shop?category=Music", label: "Music", testId: "mobile-nav-music" },
                                { to: "/shop?category=Minimal", label: "Minimal", testId: "mobile-nav-minimal" },
                                { to: "/shop?category=Abstract", label: "Abstract", testId: "mobile-nav-abstract" },
                                { to: "/about", label: "About", testId: "mobile-nav-about" },
                                { to: "/contact", label: "Contact", testId: "mobile-nav-contact" },
                            ].map((item, i) => (
                                <motion.div
                                    key={item.to}
                                    initial={{ opacity: 0, y: 24 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0, y: 12 }}
                                    transition={{ duration: 0.55, ease: [0.2, 0.7, 0.2, 1], delay: 0.3 + i * 0.06 }}
                                >
                                    <NavLink
                                        data-testid={item.testId}
                                        to={item.to}
                                        onClick={() => setMobileOpen(false)}
                                        className="group flex items-center justify-between py-4 border-b border-black/5"
                                    >
                                        <span className="font-serif-display text-4xl leading-tight tracking-tighter group-hover:text-[#FF3B30] transition-colors">
                                            {item.label}
                                        </span>
                                        <ArrowUpRight className="w-5 h-5 opacity-40 group-hover:opacity-100 group-hover:text-[#FF3B30] transition" />
                                    </NavLink>
                                </motion.div>
                            ))}
                        </nav>

                        {/* Footer strip */}
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ duration: 0.4, delay: 0.9 }}
                            className="mt-auto p-6 border-t border-black/5 flex flex-wrap gap-4 items-center justify-between text-xs text-pz-muted"
                        >
                            <div className="flex gap-4">
                                <Link to="/wishlist" onClick={() => setMobileOpen(false)} className="inline-flex items-center gap-1.5 hover:text-[#FF3B30]">
                                    <Heart className="w-4 h-4" /> Wishlist{wishCount > 0 && ` (${wishCount})`}
                                </Link>
                                <button onClick={() => { setMobileOpen(false); setTimeout(() => setOpen(true), 300); }} className="inline-flex items-center gap-1.5 hover:text-[#FF3B30]">
                                    <ShoppingBag className="w-4 h-4" /> Cart{count > 0 && ` (${count})`}
                                </button>
                            </div>
                            <div className="text-[10px] tracking-widest uppercase">hello@posterzone.in</div>
                        </motion.div>
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>
        </>
    );
}
