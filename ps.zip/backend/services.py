"""S3-compatible object storage + Resend email + email templates for Poster Zone."""
import os
import uuid
import asyncio
import logging
from typing import Optional

import boto3
from botocore.client import Config as BotoConfig
from botocore.exceptions import BotoCoreError, ClientError
import resend

log = logging.getLogger("posterzone.services")

_s3_client = None
_bucket: Optional[str] = None


def _bucket_name() -> str:
    return os.environ.get("S3_BUCKET", "")


def _app_prefix() -> str:
    return os.environ.get("STORAGE_APP_NAME", "posterzone")


# ---------- Object storage (any S3-compatible provider: AWS S3, Cloudflare R2,
# Backblaze B2, DigitalOcean Spaces, MinIO, ...) ----------
def init_storage() -> Optional[str]:
    """Lazily create the S3 client. Returns the bucket name if configured, else None."""
    global _s3_client, _bucket
    if _s3_client and _bucket:
        return _bucket
    bucket = _bucket_name()
    if not bucket:
        log.warning("S3_BUCKET not set — object storage disabled")
        return None
    try:
        kwargs = {}
        access_key = os.environ.get("S3_ACCESS_KEY_ID")
        secret_key = os.environ.get("S3_SECRET_ACCESS_KEY")
        if access_key and secret_key:
            kwargs["aws_access_key_id"] = access_key
            kwargs["aws_secret_access_key"] = secret_key
        # endpoint_url lets this point at R2 / Spaces / B2 / MinIO instead of AWS
        endpoint_url = os.environ.get("S3_ENDPOINT_URL") or None
        _s3_client = boto3.client(
            "s3",
            region_name=os.environ.get("S3_REGION", "us-east-1"),
            endpoint_url=endpoint_url,
            config=BotoConfig(signature_version="s3v4"),
            **kwargs,
        )
        _bucket = bucket
        log.info(f"Object storage initialized (bucket={bucket})")
    except (BotoCoreError, ClientError, Exception) as e:
        log.error(f"Storage init failed: {e}")
        _s3_client = None
        _bucket = None
    return _bucket


def put_object(path: str, data: bytes, content_type: str) -> dict:
    bucket = init_storage()
    if not bucket:
        raise RuntimeError("Object storage not initialized — set S3_BUCKET and S3 credentials")
    _s3_client.put_object(Bucket=bucket, Key=path, Body=data, ContentType=content_type)
    return {"path": path, "size": len(data)}


def get_object(path: str) -> tuple[bytes, str]:
    bucket = init_storage()
    if not bucket:
        raise RuntimeError("Object storage not initialized — set S3_BUCKET and S3 credentials")
    try:
        obj = _s3_client.get_object(Bucket=bucket, Key=path)
    except ClientError as e:
        raise RuntimeError(f"Object not found: {path}") from e
    return obj["Body"].read(), obj.get("ContentType", "application/octet-stream")


MIME_TYPES = {
    "jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png",
    "gif": "image/gif", "webp": "image/webp",
}


def guess_ext(filename: str, content_type: str) -> str:
    if "." in filename:
        ext = filename.rsplit(".", 1)[-1].lower()
        if ext in MIME_TYPES:
            return ext
    for ext, mt in MIME_TYPES.items():
        if mt == content_type:
            return ext
    return "bin"


# ---------- Resend email ----------
def _rk() -> str:
    return os.environ.get("RESEND_API_KEY", "")


async def send_email(to_email: str, subject: str, html: str) -> Optional[str]:
    """Send email via Resend. Returns email id, or None if key missing/failure."""
    key = _rk()
    if not key:
        log.info(f"[email skipped — no RESEND_API_KEY] to={to_email} subject={subject!r}")
        return None
    resend.api_key = key
    sender = os.environ.get("SENDER_EMAIL", "onboarding@resend.dev")
    params = {"from": sender, "to": [to_email], "subject": subject, "html": html}
    try:
        result = await asyncio.to_thread(resend.Emails.send, params)
        log.info(f"Email sent to {to_email} id={result.get('id')}")
        return result.get("id")
    except Exception as e:
        log.error(f"Email send failed to {to_email}: {e}")
        return None


# ---------- Templates ----------
BRAND = "Poster Zone"
ACCENT = "#FF3B30"
INK = "#0A0A0A"


def _fmt_inr(n) -> str:
    return f"₹{int(n):,}"


def _base(inner_html: str, title: str) -> str:
    return f"""
<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>{title}</title></head>
<body style="margin:0;padding:0;background:#FAFAFA;font-family:Helvetica,Arial,sans-serif;color:{INK};">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#FAFAFA;padding:40px 0;">
  <tr><td align="center">
    <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border:1px solid #E4E4E7;">
      <tr><td style="padding:32px 40px;border-bottom:1px solid #E4E4E7;">
        <div style="font-family:Georgia,serif;font-size:32px;letter-spacing:-0.02em;">Poster<span style="color:{ACCENT};">.</span>Zone</div>
      </td></tr>
      <tr><td style="padding:40px;">{inner_html}</td></tr>
      <tr><td style="padding:24px 40px;background:{INK};color:#ffffff;font-size:12px;">
        <div style="opacity:0.7;">© {BRAND} — Printed. Framed. Shipped.</div>
        <div style="opacity:0.5;margin-top:4px;">hello@posterzone.in</div>
      </td></tr>
    </table>
  </td></tr>
</table>
</body></html>
"""


def order_placed_html(order: dict) -> str:
    addr = order.get("shipping_address", {})
    rows = "".join(
        f"""<tr>
          <td style="padding:12px 0;border-bottom:1px solid #F4F4F5;width:56px;">
            <img src="{i['image_url']}" alt="" width="56" style="display:block;border:1px solid #E4E4E7;" />
          </td>
          <td style="padding:12px 12px;border-bottom:1px solid #F4F4F5;font-size:14px;">
            <div style="font-weight:600;">{i['title']}</div>
            <div style="color:#52525B;font-size:12px;margin-top:2px;">{i['size']} · {i['frame']} × {i['quantity']}</div>
          </td>
          <td style="padding:12px 0;border-bottom:1px solid #F4F4F5;font-size:14px;text-align:right;">{_fmt_inr(i['unit_price']*i['quantity'])}</td>
        </tr>"""
        for i in order.get("items", [])
    )
    inner = f"""
      <div style="font-family:Georgia,serif;font-size:36px;line-height:1.05;letter-spacing:-0.02em;">On the way<span style="color:{ACCENT};">.</span></div>
      <p style="color:#52525B;line-height:1.6;margin:16px 0;">
        Thanks {addr.get('name','')}, we've received your order and are packing it now.
        Your art will be dispatched within 2 business days.
      </p>
      <div style="margin-top:24px;text-transform:uppercase;letter-spacing:0.18em;font-size:11px;color:#52525B;">Order</div>
      <div style="font-size:18px;font-weight:600;margin-top:4px;">{order.get('order_id')}</div>

      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-top:24px;">{rows}</table>

      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-top:16px;font-size:14px;">
        <tr><td style="color:#52525B;padding:4px 0;">Subtotal</td><td style="text-align:right;padding:4px 0;">{_fmt_inr(order.get('subtotal',0))}</td></tr>
        <tr><td style="color:#52525B;padding:4px 0;">Shipping</td><td style="text-align:right;padding:4px 0;">{'Free' if order.get('shipping',0)==0 else _fmt_inr(order.get('shipping',0))}</td></tr>
        <tr><td style="padding:10px 0 4px;border-top:1px solid #E4E4E7;font-weight:600;">Total</td><td style="text-align:right;padding:10px 0 4px;border-top:1px solid #E4E4E7;font-weight:600;">{_fmt_inr(order.get('total',0))}</td></tr>
      </table>

      <div style="margin-top:32px;text-transform:uppercase;letter-spacing:0.18em;font-size:11px;color:#52525B;">Shipping to</div>
      <div style="font-size:14px;margin-top:6px;line-height:1.5;">
        {addr.get('name','')}<br/>
        {addr.get('address','')}<br/>
        {addr.get('city','')}, {addr.get('state','')} {addr.get('pincode','')}<br/>
        {addr.get('phone','')}
      </div>
    """
    return _base(inner, f"Order {order.get('order_id')} confirmed")


def order_shipped_html(order: dict) -> str:
    addr = order.get("shipping_address", {})
    inner = f"""
      <div style="font-family:Georgia,serif;font-size:36px;line-height:1.05;letter-spacing:-0.02em;">Shipped<span style="color:{ACCENT};">.</span></div>
      <p style="color:#52525B;line-height:1.6;margin:16px 0;">
        Great news {addr.get('name','')} — your Poster Zone order is on its way. It should reach you within 3-5 business days.
      </p>
      <div style="margin-top:24px;text-transform:uppercase;letter-spacing:0.18em;font-size:11px;color:#52525B;">Order</div>
      <div style="font-size:18px;font-weight:600;margin-top:4px;">{order.get('order_id')}</div>
      <p style="color:#52525B;line-height:1.6;margin-top:24px;">
        Once your prints arrive, take a photo and tag <b>@posterzone</b> on Instagram — we love seeing them on your walls.
      </p>
    """
    return _base(inner, f"Order {order.get('order_id')} shipped")
