# Auth-Gated App Testing Playbook

## Step 1: Create Test User & Session (Google Auth path)
```
mongosh --eval "
use('test_database');
var userId = 'test-user-' + Date.now();
var sessionToken = 'test_session_' + Date.now();
db.users.insertOne({
  user_id: userId,
  email: 'test.user.' + Date.now() + '@example.com',
  name: 'Test User',
  picture: 'https://via.placeholder.com/150',
  role: 'user',
  created_at: new Date()
});
db.user_sessions.insertOne({
  user_id: userId,
  session_token: sessionToken,
  expires_at: new Date(Date.now() + 7*24*60*60*1000),
  created_at: new Date()
});
print('Session token: ' + sessionToken);
print('User ID: ' + userId);
"
```

## Step 2: Test Backend API
```
# Test auth endpoint
curl -X GET "$BACKEND/api/auth/me" -H "Authorization: Bearer YOUR_SESSION_TOKEN"
# JWT flow login
curl -X POST "$BACKEND/api/auth/login" -H "Content-Type: application/json" \
  -d '{"email":"admin@posterzone.com","password":"Admin@12345"}'
```

## Step 3: Browser Testing (Playwright)
Set cookie `session_token` with `secure=true, sameSite=None, httpOnly=true`.

## Checklist
- User document has `user_id` field
- Session `user_id` matches user's `user_id`
- All queries use `{"_id": 0}` projection
- Backend uses `user_id` (not `_id`)
- Callback detection uses `useLocation().hash`
